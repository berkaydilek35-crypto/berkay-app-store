#!/bin/bash
# Jarvis kurulumu (macOS, Apple Silicon önerilir).
# Kullanım:  bash kur.sh            (tanıtımı atlamak için: bash kur.sh --tanitma)
set -e
D="$(cd "$(dirname "$0")" && pwd)"
EV="$HOME/.jarvis-asistan"; mkdir -p "$EV"
PL="$HOME/Library/LaunchAgents/com.jarvis-asistan.plist"

[ "$(uname)" = "Darwin" ] || { echo "Bu kurulum macOS içindir."; exit 1; }

# 1) Gemini API anahtarı (bir kez)
if [ ! -s "$EV/gemini.key" ]; then
  echo "Gemini API anahtarı gerekiyor (ücretsiz katmanı var):"
  echo "  https://aistudio.google.com/apikey adresinden 'Create API key' ile oluştur ve kopyala."
  read -r -p "Kopyaladıysan Enter'a bas (panodan okunacak)… " _
  pbpaste | tr -d '[:space:]' > "$EV/gemini.key"; chmod 600 "$EV/gemini.key"
  [ -s "$EV/gemini.key" ] || { echo "Pano boş görünüyor; anahtarı kopyalayıp kurulumu tekrar çalıştır."; exit 1; }
fi

# 2) ayarlar ve klasör
[ -f "$EV/ayarlar.json" ] || cp "$D/ayarlar.ornek.json" "$EV/ayarlar.json"
KL="$(/usr/bin/python3 -c "import json,os;print(os.path.expanduser(json.load(open('$EV/ayarlar.json')).get('klasor','~/Jarvis')))" 2>/dev/null || echo "$HOME/Jarvis")"
mkdir -p "$KL/konusmalar"
[ -f "$KL/KIMLIK.md" ] || cp "$D/KIMLIK.ornek.md" "$KL/KIMLIK.md"

# 3) Python 3.12 ve paketler (uv ile, sistem Python'una dokunmadan)
UV="$(command -v uv || true)"; [ -z "$UV" ] && [ -x "$HOME/.local/bin/uv" ] && UV="$HOME/.local/bin/uv"
if [ -z "$UV" ]; then echo "uv kuruluyor…"; curl -LsSf https://astral.sh/uv/install.sh | sh >/dev/null; UV="$HOME/.local/bin/uv"; fi
[ -x "$EV/venv/bin/python" ] || "$UV" venv -q --python 3.12 "$EV/venv"
PY="$EV/venv/bin/python"
echo "Paketler kuruluyor (2-4 dk)…"
"$UV" pip install -q --python "$PY" "openwakeword==0.6.0" onnxruntime sounddevice numpy scipy scikit-learn tqdm requests websockets pywebrtc-audio fastembed browser-use
cp "$D/jarvis.py" "$EV/jarvis.py"
"$PY" -c "from openwakeword.utils import download_models; download_models(['hey_jarvis']); print('uyandırma modeli hazır')"

# 4) bağlantı testi
"$PY" "$EV/jarvis.py" --test || true

# 5) sesine özel "Hey Jarvis" tanıtımı (isteğe bağlı ama önerilir)
launchctl bootout "gui/$(id -u)" "$PL" 2>/dev/null || true
if [ "$1" != "--tanitma" ] && [ ! -f "$EV/dogrulayici.pkl" ]; then
  "$PY" "$EV/jarvis.py" --tanit || echo "Tanıtım tamamlanmadı; sonra: $PY $EV/jarvis.py --tanit"
fi

# 6) hafıza dizini
"$PY" "$EV/jarvis.py" --hafiza-kur || true

# 7) arka plan servisi
cat > "$PL" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>com.jarvis-asistan</string>
  <key>ProgramArguments</key><array><string>$PY</string><string>$EV/jarvis.py</string></array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>ProcessType</key><string>Interactive</string>
  <key>StandardOutPath</key><string>$EV/servis.out.log</string>
  <key>StandardErrorPath</key><string>$EV/servis.err.log</string>
</dict></plist>
EOF
launchctl bootstrap "gui/$(id -u)" "$PL"
sleep 6
tail -n 3 "$EV/jarvis.log" 2>/dev/null || true
echo
echo "Kuruldu. 'Hey Jarvis' de. Mikrofon izni sorulursa 'İzin ver'."
echo "Kimliğini düzenle: $KL/KIMLIK.md     Canlı log: tail -f ~/.jarvis-asistan/jarvis.log"
