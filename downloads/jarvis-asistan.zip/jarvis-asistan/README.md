# Jarvis — Mac için Türkçe sesli asistan

"Hey Jarvis" de, anında sesli cevap versin. Konuşmalarınızı hatırlasın, notlarında arasın, internette araştırsın, gerekirse ekranına baksın.

- **Uyanma kelimesi:** "Hey Jarvis"i Mac'inde, internete çıkmadan yakalar. İstersen kendi sesinle eğitirsin, böylece sadece senin sesinle uyanır.
- **Anında sesli konuşma:** Google Gemini Live ile konuşursun. Jarvis konuşurken araya girip sözünü kesebilirsin; yankı engelleme ve gürültü bastırma açık.
- **Hafıza:** Her konuşmanın yazılı dökümü kendi klasöründe tutulur. "Geçen hafta ne konuşmuştuk?" diye sorabilirsin. Arama hem kelimeyle hem anlamla, tamamen Mac'te yapılır.
- **Kişilik:** `KIMLIK.md` dosyasına kim olduğunu ve Jarvis'in nasıl konuşmasını istediğini yazarsın.
- **Araçlar:**
  - Google araması
  - YouTube araması (izlenme sayıları)
  - Web sayfası okuma
  - Not alma ("bunu hatırla", "not al")
  - Ekrana bakma (sadece sen isteyince)
  - Kendi kendine internette çok adımlı iş yapan tarayıcı ajanı
- **Gizlilik:** Ses diske kaydedilmez. Sadece konuşurken sesin Google'a gider. Dökümler, notlar ve hafıza senin Mac'inde kalır.

## Gerekenler

- Apple Silicon'lu bir Mac (M1 ve sonrası) ve macOS 13 ya da üstü
- Ücretsiz bir **Gemini API anahtarı**: [aistudio.google.com/apikey](https://aistudio.google.com/apikey)
- 4 GB boş disk (modeller için)

## Kurulum (5 dakika)

1. Bu klasörü indir ve aç.
2. Terminal'i aç, klasöre gir ve kurulumu çalıştır:
   ```bash
   cd ~/Downloads/jarvis-asistan
   bash kur.sh
   ```
3. Kurulum senden şunları ister:
   - **Gemini anahtarı:** Anahtarı kopyala, Enter'a bas; kurulum panodan kendisi okur.
   - **"Hey Jarvis" tanıtımı:** Yaklaşık 2 dakika. 10 kez "Hey Jarvis" dersin (bip sesinden **sonra**), 25 saniye normal konuşursun, 10 saniye susarsın. Atlamak için `bash kur.sh --tanitma`.
   - **Mikrofon izni:** macOS sorarsa "İzin ver".
4. Bitti. **"Hey Jarvis"** de.

## Kendine göre ayarla

- **Kimlik:** `~/Jarvis/KIMLIK.md` dosyasını aç, köşeli parantezli yerleri doldur. Jarvis bir sonraki konuşmada okur.
- **Ayarlar:** `~/.jarvis-asistan/ayarlar.json`. Değiştirince servisi yeniden başlat (aşağıda).

| Ayar | Ne işe yarar |
|---|---|
| `kullanici_adi` | Jarvis sana nasıl hitap etsin |
| `selam` | Uyanınca ne desin ("Efendim", "Buyur") |
| `klasor` | Notların, hafızanın ve konuşma dökümlerinin klasörü (varsayılan `~/Jarvis`). Kendi notlarını buraya koyarsan Jarvis onlarda da arar |
| `ses` | Jarvis'in sesi: `Charon`, `Puck`, `Kore`, `Aoede`, `Fenrir`… |
| `uyanma_esigi` | Kendi kendine açılıyorsa yükselt (0.7), seni duymuyorsa düşür (0.5) |
| `kapanma_sn` | Sustuktan kaç saniye sonra uykuya dönsün |
| `yanki_engelleme` | Araya girebilmek için açık kalsın |
| `telegram_bot_token`, `telegram_chat_id` | İsteğe bağlı. Kendi Telegram botunu yazarsan tarayıcı görevlerinin sonucu oraya gelir |

## Kullanım

- **Uyandırma:** "Hey Jarvis" de. "Efendim" der, sonra sorunu sor. Cevaptan sonra "Hey Jarvis" demeden devam edebilirsin.
- **Kapatma:** "kapanabilirsin", "uyu" ya da "görüşürüz" de. 30 saniye konuşmazsan da kendi uykuya döner.
- **Örnekler:**
  - "Bunu hatırla: Pazartesi toplantı 10'da."
  - "Geçen hafta ne konuşmuştuk?"
  - "YouTube'da şu videonun izlenmesi kaç?"
  - "Ekrana bak, bu hata ne?"
  - "Şu konuyu internette araştırıp bana liste çıkar." (Tarayıcı görevi; arka planda çalışır.)

## Yönetim

```bash
# canlı log
tail -f ~/.jarvis-asistan/jarvis.log

# geçici olarak kapat / aç (mikrofon kullanılmaz)
touch ~/.jarvis-asistan/kapali
rm ~/.jarvis-asistan/kapali

# ayar değişikliğinden sonra yeniden başlat
launchctl kickstart -k gui/$(id -u)/com.jarvis-asistan

# "Hey Jarvis"i sesine göre yeniden eğit
~/.jarvis-asistan/venv/bin/python ~/.jarvis-asistan/jarvis.py --tanit

# mikrofon ve Gemini bağlantısını dene
~/.jarvis-asistan/venv/bin/python ~/.jarvis-asistan/jarvis.py --test

# tamamen kaldır (notların silinmez)
bash kaldir.sh
```

## Maliyet

Gemini API'nin ücretsiz katmanıyla başlayabilirsin. Ücretsiz katmanın limitleri düşüktür ve Google bu katmandaki verileri modellerini geliştirmek için kullanabilir. Ücretli katmanda maliyet, konuşma süresine bağlıdır; güncel fiyatlar için [Gemini API fiyatları](https://ai.google.dev/gemini-api/docs/pricing) sayfasına bak.

Masrafı düşük tutmak için:
- Jarvis sustuğunda uykuya döner.
- "Hey Jarvis"i yakalamak, hafıza araması, yankı engelleme ve gürültü bastırma Mac'te ücretsiz çalışır.

## Sorun giderme

- **Hiç uyanmıyor:**
  - `--test` ile mikrofon seviyesine bak.
  - Sistem Ayarları > Gizlilik > Mikrofon'da Python'a izin ver.
  - `uyanma_esigi`'ni düşür.
- **Kendi kendine açılıyor:** `uyanma_esigi`'ni 0.7'ye çıkar ya da `--tanit` ile kendi sesine eğit.
- **"Bağlanamıyorum" diyor:**
  - Anahtarı ve interneti kontrol et.
  - Model adı değiştiyse `ayarlar.json`'da `canli_model`'i güncelle.
- **Ekrana bakamıyor:** Sistem Ayarları > Gizlilik > Ekran ve Sistem Sesi Kaydı'nda Python'a izin ver.
- **Uyanınca Türkçe konuşmuyor, bip sesi çalıyor:** Sistem Ayarları > Erişilebilirlik > Seslendirilen İçerik > Sistem sesi'nden Türkçe "Yelda" sesini indir.

## Kullanılan açık kaynak projeler

- [openWakeWord](https://github.com/dscripka/openWakeWord) — "Hey Jarvis" uyanma kelimesi ve konuşma algılama
- [pywebrtc-audio](https://pypi.org/project/pywebrtc-audio/) — WebRTC yankı engelleme ve gürültü bastırma
- [fastembed](https://github.com/qdrant/fastembed) — Mac'te çok dilli anlam araması
- [browser-use](https://github.com/browser-use/browser-use) — tarayıcı ajanı
- [Gemini Live API](https://ai.google.dev/gemini-api/docs/live-api/get-started-websocket) — canlı sesli konuşma

## Lisans

MIT. Dilediğin gibi kullan, değiştir, paylaş.
