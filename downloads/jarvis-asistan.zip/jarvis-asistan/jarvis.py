#!/usr/bin/env python3
"""Jarvis — Mac için Türkçe, sesli, hafızalı kişisel asistan.

"Hey Jarvis" deyince uyanır, Gemini Live ile anında sesli konuşur, konuşmaları hatırlar.
Ayarlar: ~/.jarvis-asistan/ayarlar.json   Anahtar: ~/.jarvis-asistan/gemini.key   Log: ~/.jarvis-asistan/jarvis.log

Komutlar:
  python jarvis.py              arka plan servisi (kur.sh bunu launchd ile başlatır)
  python jarvis.py --tanit      "Hey Jarvis"i sesine göre eğit (doğrulayıcı)
  python jarvis.py --hafiza-kur hafıza arama dizinini kur
  python jarvis.py --test       mikrofon ve Gemini bağlantısını dene

MIT lisansı. Ses diske kaydedilmez; yalnızca konuşmanın yazılı dökümü senin klasöründe tutulur.
"""
import os, sys, re, glob, json, time, base64, queue, tempfile, datetime, subprocess, threading, urllib.request, urllib.parse
import numpy as np

# ------------------------------------------------------------------ ayarlar
EV = os.path.expanduser(os.environ.get('JARVIS_EV', '~/.jarvis-asistan'))
os.makedirs(EV, exist_ok=True)
LOG = os.path.join(EV, 'jarvis.log')
ANAHTAR_DOSYA = os.path.join(EV, 'gemini.key')
VARSAYILAN = {
    'kullanici_adi': 'Kullanıcı',            # Jarvis sana nasıl hitap etsin
    'selam': 'Efendim',                       # uyanınca söyleyeceği söz
    'klasor': '~/Jarvis',                     # hafıza, konuşmalar ve notların durduğu klasör
    'canli_model': 'models/gemini-3.8-live',  # Gemini Live modeli
    'metin_model': 'gemini-flash-latest',     # ekran yorumu ve tarayıcı ajanı için
    'ses': 'Charon',                          # Gemini ses adı (Charon, Puck, Kore, Aoede, Fenrir…)
    'mac_sesi': 'Yelda',                      # yedek Türkçe macOS sesi (say -v)
    'uyanma_esigi': 0.6,                      # 0-1; yanlış uyanma olursa yükselt, duymazsa düşür
    'on_esik': 0.45,                          # doğrulayıcı varsa temel modelin geçmesi gereken skor
    'kapanma_sn': 30,                         # son konuşmadan bu kadar sonra uykuya dön
    'ilk_soru_sn': 8,                         # uyanınca bu sürede soru gelmezse kapan
    'yanki_engelleme': True,                  # Jarvis konuşurken araya girebilmek için
    'telegram_bot_token': '',                 # isteğe bağlı: tarayıcı görevi bitince bildirim
    'telegram_chat_id': ''
}


def ayarlar():
    a = dict(VARSAYILAN)
    try:
        with open(os.path.join(EV, 'ayarlar.json'), encoding='utf-8') as f:
            a.update(json.load(f))
    except Exception:
        pass
    return a


A = ayarlar()
KLASOR = os.path.expanduser(A['klasor'])
KONUSMA_KLASOR = os.path.join(KLASOR, 'konusmalar')
for _k in (KLASOR, KONUSMA_KLASOR):
    os.makedirs(_k, exist_ok=True)
ORAN, KARE = 16000, 1280          # 16 kHz, 80 ms kareler (openWakeWord kare boyu)
DOGRULAYICI = os.path.join(EV, 'dogrulayici.pkl')
KAPALI = os.path.join(EV, 'kapali')   # bu dosya varken Jarvis mikrofonu açmaz
CANLI_WS = 'wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent'


def log(m):
    s = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + ' ' + m
    try:
        if os.path.exists(LOG) and os.path.getsize(LOG) > 2_000_000:
            os.replace(LOG, LOG + '.1')
        with open(LOG, 'a', encoding='utf-8') as f:
            f.write(s + '\n')
    except Exception:
        pass
    if sys.stdout.isatty():
        print(s, flush=True)


def anahtar():
    try:
        with open(ANAHTAR_DOSYA) as f:
            return ''.join(f.read().split())
    except Exception:
        return ''


def rms(k):
    x = k.astype(np.float32) / 32768.0
    return float(np.sqrt(np.mean(x * x))) if len(x) else 0.0


def tr_kucuk(x):
    return str(x or '').replace('I', 'ı').replace('İ', 'i').lower()


def oku(yol, sinir=None):
    try:
        with open(yol, encoding='utf-8', errors='ignore') as f:
            t = f.read()
        return t[:sinir] if sinir else t
    except Exception:
        return ''


def http_json(url, govde=None, zaman_asimi=60, basliklar=None):
    h = {'Content-Type': 'application/json'}
    h.update(basliklar or {})
    r = urllib.request.Request(url, data=json.dumps(govde).encode() if govde is not None else None, headers=h)
    with urllib.request.urlopen(r, timeout=zaman_asimi) as y:
        return json.loads(y.read().decode() or '{}')


def say(metin):
    r = subprocess.run(['say', '-v', A['mac_sesi'], metin[:400]], check=False, capture_output=True)
    if r.returncode != 0:      # Türkçe ses yüklü değilse kısa bir bip
        bip('Tink')


def bip(ad='Tink'):
    subprocess.run(['afplay', '/System/Library/Sounds/%s.aiff' % ad], check=False)


# ------------------------------------------------------------------ konuşma dökümü ve notlar
def konusma_yaz(ben, o):
    """Her turu günün dosyasına yazar (yalnızca metin). Hafıza araması bu dosyaları kullanır."""
    try:
        simdi = datetime.datetime.now()
        yol = os.path.join(KONUSMA_KLASOR, simdi.strftime('%Y-%m-%d') + '.md')
        yeni = not os.path.exists(yol)
        with open(yol, 'a', encoding='utf-8') as f:
            if yeni:
                f.write('# Konuşmalar — ' + simdi.strftime('%Y-%m-%d') + '\n\n')
            f.write('### ' + simdi.strftime('%H:%M') + '\n' + ('Ben: ' + ben.strip() + '\n' if ben.strip() else '')
                    + ('Jarvis: ' + o.strip() + '\n' if o.strip() else '') + '\n')
    except Exception as e:
        log('konuşma yazılamadı: ' + str(e))


def hafizaya_ekle(metin):
    yol = os.path.join(KLASOR, 'HAFIZA.md')
    yeni = not os.path.exists(yol)
    with open(yol, 'a', encoding='utf-8') as f:
        if yeni:
            f.write('# Jarvis hafızası\n\nKalıcı bilgiler, tercihler ve sözler. İstediğin gibi düzenleyebilirsin.\n\n')
        f.write('- ' + datetime.date.today().isoformat() + ': ' + metin.strip().replace('\n', ' ') + '\n')


def not_ekle(metin):
    yol = os.path.join(KLASOR, 'NOTLAR.md')
    yeni = not os.path.exists(yol)
    with open(yol, 'a', encoding='utf-8') as f:
        if yeni:
            f.write('# Notlar ve yapılacaklar\n\n')
        f.write('- [ ] ' + metin.strip().replace('\n', ' ') + ' (' + datetime.datetime.now().strftime('%d.%m %H:%M') + ')\n')


# ------------------------------------------------------------------ anlamsal + kelime hafıza araması
DURAK = set('ve ile bir bu şu o ne mi mı mu mü da de ki için gibi daha çok en var yok ben sen biz siz onlar bana sana bize ama ya veya hangi nasıl neden nerede kaç kim'.split())


class Hafiza:
    """Klasördeki tüm .md/.txt dosyalarını (konuşmalar, hafıza, notlar, kendi belgelerin) hem kelimeyle (SQLite FTS5)
    hem anlamıyla (çok dilli gömme modeli, Mac'te çalışır) arar; en alakalı birkaç kısa parçayı döner = az token."""
    MODEL = 'sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2'

    def __init__(self):
        self.yol = os.path.join(EV, 'dizin'); os.makedirs(self.yol, exist_ok=True)
        self.parcalar, self.vek, self.mtime, self.kilit, self._m = [], None, {}, threading.Lock(), None
        try:
            v = np.load(os.path.join(self.yol, 'vek.npy'))
            meta = json.load(open(os.path.join(self.yol, 'meta.json'), encoding='utf-8'))
            if len(meta['parcalar']) == len(v):
                self.parcalar, self.vek, self.mtime = meta['parcalar'], v, meta['mtime']
        except Exception:
            pass

    def _model(self):
        if self._m is None:
            from fastembed import TextEmbedding
            self._m = TextEmbedding(self.MODEL, cache_dir=os.path.join(EV, 'modeller'))
        return self._m

    def _gom(self, metinler):
        v = np.array(list(self._model().embed(metinler)), dtype=np.float32)
        return v / (np.linalg.norm(v, axis=1, keepdims=True) + 1e-9)

    @staticmethod
    def _bol(ad, metin):
        metin = re.sub(r'<!--[\s\S]*?-->', '', metin)
        gun = (re.search(r'\d{4}-\d{2}(-\d{2})?', ad) or [''])[0]
        bas, parca, out = '', [], []

        def kapat():
            t = '\n'.join(parca).strip()
            if t:
                out.append((gun, bas, t))
        for satir in metin.split('\n'):
            if re.match(r'^#{2,3} ', satir):
                kapat(); parca = []
                bas = satir.lstrip('# ').strip()
                m = re.match(r'^(\d{4}-\d{2}-\d{2})', bas)
                if m:
                    gun = m.group(1)
            else:
                parca.append(satir)
        kapat()
        son = []
        for g, b, t in out:
            for i in range(0, len(t), 1200):
                son.append({'dosya': ad, 'tarih': g, 'baslik': b[:120], 'metin': t[i:i + 1200]})
        return son

    def guncelle(self):
        adlar = sorted(a for a in set(glob.glob(os.path.join(KLASOR, '**', '*.md'), recursive=True)
                                      + glob.glob(os.path.join(KLASOR, '**', '*.txt'), recursive=True))
                       if os.path.getsize(a) < 8_000_000)
        anahtar_ = lambda a: os.path.relpath(a, KLASOR)
        mt = {anahtar_(a): os.path.getmtime(a) for a in adlar}
        if mt == self.mtime and self.vek is not None:
            return
        degisen = [a for a in adlar if self.mtime.get(anahtar_(a)) != mt[anahtar_(a)]]
        kalan = ([(p, self.vek[i]) for i, p in enumerate(self.parcalar) if p['dosya'] in mt and self.mtime.get(p['dosya']) == mt[p['dosya']]]
                 if self.vek is not None else [])
        yeni = []
        for a in degisen:
            yeni += self._bol(anahtar_(a), oku(a))
        yv = self._gom([(p['tarih'] + ' ' + p['baslik'] + '\n' + p['metin'])[:1500] for p in yeni]) if yeni else np.zeros((0, 384), np.float32)
        parcalar = [p for p, _ in kalan] + yeni
        kv = np.array([v for _, v in kalan], dtype=np.float32).reshape(len(kalan), -1) if kalan else np.zeros((0, yv.shape[1] if len(yv) else 384), np.float32)
        vek = np.vstack([kv, yv]) if parcalar else np.zeros((0, 384), np.float32)
        with self.kilit:
            self.parcalar, self.vek, self.mtime = parcalar, vek, mt
        np.save(os.path.join(self.yol, 'vek.npy'), vek)
        json.dump({'parcalar': parcalar, 'mtime': mt}, open(os.path.join(self.yol, 'meta.json'), 'w', encoding='utf-8'), ensure_ascii=False)
        self._fts_kur(parcalar)
        if yeni:
            log('hafıza dizini güncellendi: %d yeni parça, toplam %d' % (len(yeni), len(parcalar)))

    def _fts_kur(self, parcalar):
        import sqlite3
        yol = os.path.join(self.yol, 'kelime.db'); gecici = yol + '.yeni'
        try:
            os.remove(gecici)
        except OSError:
            pass
        db = sqlite3.connect(gecici)
        db.execute("CREATE VIRTUAL TABLE p USING fts5(metin, baslik, dosya, tokenize='unicode61 remove_diacritics 2')")
        db.executemany('INSERT INTO p(rowid, metin, baslik, dosya) VALUES (?,?,?,?)',
                       [(i, tr_kucuk(x['metin']), tr_kucuk(x['baslik']), tr_kucuk(x['dosya'])) for i, x in enumerate(parcalar)])
        db.commit(); db.close(); os.replace(gecici, yol)

    def _kelime(self, soru, n=20):
        import sqlite3
        yol = os.path.join(self.yol, 'kelime.db')
        if not os.path.exists(yol):
            return []
        kel = [w for w in re.findall(r'\w+', tr_kucuk(soru)) if len(w) >= 2 and w not in DURAK][:12]
        if not kel:
            return []
        ifade = ' OR '.join('"%s"*' % (w[:5] if len(w) > 6 else w) for w in kel)   # Türkçe ekler için kök araması
        try:
            db = sqlite3.connect(yol)
            sat = db.execute('SELECT rowid FROM p WHERE p MATCH ? ORDER BY bm25(p, 1.0, 2.0, 1.5) LIMIT ?', (ifade, n)).fetchall()
            db.close()
            return [r[0] for r in sat]
        except Exception:
            return []

    def ara(self, soru, k=5):
        with self.kilit:
            parcalar, vek = self.parcalar, self.vek
        if vek is None or not len(parcalar):
            return {'sonuc': 'Hafızada henüz bir şey yok.'}
        s = vek @ self._gom([soru])[0]
        anlam = [int(i) for i in np.argsort(-s)[:20]]
        kelime = [i for i in self._kelime(soru) if i < len(parcalar)]
        puan = {}
        for sira, i in enumerate(anlam):
            puan[i] = puan.get(i, 0) + 1.0 / (60 + sira)
        for sira, i in enumerate(kelime):
            puan[i] = puan.get(i, 0) + 1.2 / (60 + sira)
        en = sorted(puan, key=lambda i: -puan[i])[:k]
        return {'sonuclar': [{'dosya': parcalar[i]['dosya'], 'tarih': parcalar[i]['tarih'], 'baslik': parcalar[i]['baslik'],
                              'metin': parcalar[i]['metin'][:600]} for i in en]}


HAFIZA = None


def hafiza_dongu():
    global HAFIZA
    try:
        h = Hafiza(); h.guncelle(); HAFIZA = h
    except Exception as e:
        log('hafıza araması açılamadı: ' + str(e)[:150]); return
    while True:
        time.sleep(600)
        try:
            h.guncelle()
        except Exception as e:
            log('hafıza güncellenemedi: ' + str(e)[:100])


# ------------------------------------------------------------------ araçlar: web, YouTube, ekran, tarayıcı
UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36'


def _getir(url, zaman_asimi=15):
    r = urllib.request.Request(url, headers={'User-Agent': UA, 'Accept-Language': 'tr-TR,tr;q=0.9,en;q=0.8', 'Cookie': 'CONSENT=YES+1; SOCS=CAI'})
    with urllib.request.urlopen(r, timeout=zaman_asimi) as y:
        return y.read().decode('utf-8', 'ignore')


def _json_sonrasi(html, isaret):
    i = html.find(isaret)
    if i < 0:
        return None
    i = html.find('{', i)
    try:
        return json.JSONDecoder().raw_decode(html[i:])[0]
    except Exception:
        return None


def _bul(o, anahtar_, sonuc, sinir=20):
    if len(sonuc) >= sinir:
        return
    if isinstance(o, dict):
        if anahtar_ in o:
            sonuc.append(o[anahtar_])
        for v in o.values():
            _bul(v, anahtar_, sonuc, sinir)
    elif isinstance(o, list):
        for v in o:
            _bul(v, anahtar_, sonuc, sinir)


def _metin(x):
    if not isinstance(x, dict):
        return ''
    return x.get('simpleText') or ''.join(r.get('text', '') for r in x.get('runs') or [])


def youtube_ara(sorgu):
    html = _getir('https://www.youtube.com/results?hl=tr&gl=TR&search_query=' + urllib.parse.quote(sorgu))
    veri = _json_sonrasi(html, 'ytInitialData')
    if not veri:
        return {'hata': 'YouTube sonuçları okunamadı.'}
    vr = []; _bul(veri, 'videoRenderer', vr, 8)
    videolar = [{'baslik': _metin(v.get('title')), 'kanal': _metin(v.get('ownerText')), 'izlenme': _metin(v.get('viewCountText')),
                 'yayin': _metin(v.get('publishedTimeText')), 'sure': _metin(v.get('lengthText')), 'id': v.get('videoId')} for v in vr[:6]]
    if videolar and videolar[0].get('id'):
        try:
            pr = _json_sonrasi(_getir('https://www.youtube.com/watch?hl=tr&v=' + videolar[0]['id']), 'ytInitialPlayerResponse') or {}
            vd = pr.get('videoDetails') or {}
            if vd.get('viewCount'):
                videolar[0]['tamIzlenme'] = int(vd['viewCount'])
        except Exception:
            pass
    return {'sorgu': sorgu, 'videolar': videolar} if videolar else {'sonuc': 'Video bulunamadı.'}


def web_oku(url):
    if not re.match(r'^https?://', url or ''):
        return {'hata': 'Geçerli bir adres değil.'}
    html = re.sub(r'(?is)<(script|style|noscript|svg)[^>]*>.*?</\1>', ' ', _getir(url))
    t = re.sub(r'(?s)<[^>]+>', ' ', html)
    t = re.sub(r'&nbsp;', ' ', t); t = re.sub(r'&amp;', '&', t); t = re.sub(r'\s+', ' ', t).strip()
    return {'url': url, 'metin': t[:6000]}


def ekran_goruntusu():
    yol = os.path.join(tempfile.gettempdir(), 'jarvis_ekran.jpg')
    try:
        subprocess.run(['screencapture', '-x', '-t', 'jpg', yol], check=True, timeout=10)
        subprocess.run(['sips', '-Z', '1280', yol, '--out', yol], check=False, timeout=10, capture_output=True)
        with open(yol, 'rb') as f:
            return f.read()
    finally:
        try:
            os.remove(yol)
        except Exception:
            pass


def gemini_metin(parcalar, zaman_asimi=60):
    """Ayrı (canlı olmayan) Gemini çağrısı: ekran yorumu gibi işler için."""
    son = ''
    for model in (A['metin_model'], 'gemini-2.5-flash'):
        try:
            v = http_json('https://generativelanguage.googleapis.com/v1beta/models/' + model + ':generateContent',
                          {'contents': [{'parts': parcalar}]}, zaman_asimi, {'x-goog-api-key': anahtar()})
            return ''.join(p.get('text', '') for p in v['candidates'][0]['content']['parts']).strip()
        except Exception as e:
            son = str(e)[:120]
    raise RuntimeError(son)


def ekran_yorumla(neden):
    img = ekran_goruntusu()
    return gemini_metin([{'text': 'Bu, kullanıcının Mac ekranının şu anki görüntüsü. Türkçe, kısa ve somut anlat: hangi uygulama/site açık, '
                                  'ekranda ne yazıyor, önemli isim, rakam, başlıklar. Tablo/liste varsa özetle. Odak: ' + (neden or 'genel')},
                         {'inline_data': {'mime_type': 'image/jpeg', 'data': base64.b64encode(img).decode()}}])


def bildir(metin):
    """İsteğe bağlı Telegram bildirimi (ayarlarda kendi bot token'ın ve chat id'n varsa)."""
    tok, cid = A.get('telegram_bot_token'), A.get('telegram_chat_id')
    if not tok or not cid:
        return
    try:
        http_json('https://api.telegram.org/bot%s/sendMessage' % tok, {'chat_id': cid, 'text': metin[:3900]}, 30)
    except Exception as e:
        log('Telegram bildirimi gitmedi: ' + str(e)[:80])


TARAYICI_KURAL = ("KESİN KURALLAR: Sadece bilgi topla ve oku. Hiçbir formu gönderme, hiçbir şey satın alma, sepete ekleme, "
                  "mesaj/e-posta/yorum gönderme, hesap açma, giriş yapma, şifre ya da kart bilgisi girme, dosya indirme yok. "
                  "Bunlardan biri gerekirse dur ve sonuçta 'Kullanıcının onayı gerekiyor: …' diye yaz. "
                  "Sonucu Türkçe, kısa ve somut yaz: isimler, sayılar, linkler. Bulamadığını uydurma.")
GOREVLER = {}


def tarayici_baslat(gorev):
    if [g for g in GOREVLER.values() if g['durum'] == 'çalışıyor']:
        return {'hata': 'Şu an başka bir tarayıcı görevi çalışıyor.'}
    no = str(len(GOREVLER) + 1)
    cikti = os.path.join(EV, 'tarayici_%s.json' % no)
    GOREVLER[no] = {'gorev': gorev, 'durum': 'çalışıyor', 'sonuc': '', 'bas': time.time()}

    def calis():
        try:
            subprocess.run([sys.executable, os.path.abspath(__file__), '--tarayici', gorev, cikti], timeout=900, check=False)
            r = json.load(open(cikti, encoding='utf-8'))
        except Exception as e:
            r = {'sonuc': 'Görev tamamlanamadı: ' + str(e)[:150]}
        g = GOREVLER[no]; g['durum'] = 'bitti'; g['sonuc'] = r.get('sonuc') or ''
        log('tarayıcı görevi bitti: ' + g['sonuc'][:150])
        konusma_yaz('[Tarayıcı görevi] ' + gorev, g['sonuc'])
        bildir('Jarvis tarayıcı görevi bitti\nGörev: ' + gorev[:300] + '\n\n' + g['sonuc'])
    threading.Thread(target=calis, daemon=True).start()
    return {'durum': "Görevi başlattım (no %s). Ayrı bir tarayıcıda çalışıyor; bitince sonucu tarayici_durum ile söyleyebilirim. Kullanıcıya kısaca 'başladım, bitince haber vereceğim' de." % no}


def tarayici_durum():
    if not GOREVLER:
        return {'durum': 'Henüz tarayıcı görevi yok.'}
    return {'gorevler': [{'no': n, 'gorev': g['gorev'][:200], 'durum': g['durum'], 'sure_sn': int(time.time() - g['bas']),
                          'sonuc': g['sonuc'][:2500]} for n, g in list(GOREVLER.items())[-3:]]}


def tarayici_isci(gorev, cikti):
    """Ayrı süreçte: browser-use ajanı, kendi Chrome profilinde (senin oturumların yok)."""
    os.environ.setdefault('ANONYMIZED_TELEMETRY', 'false'); os.environ.setdefault('BROWSER_USE_CLOUD_SYNC', 'false')
    import asyncio
    try:
        from browser_use import Agent, ChatGoogle, BrowserProfile
        ajan = Agent(task=gorev, llm=ChatGoogle(model=A['metin_model'], api_key=anahtar()),
                     browser_profile=BrowserProfile(headless=False, enable_default_extensions=False, user_data_dir=os.path.join(EV, 'tarayici_profil')),
                     extend_system_message=TARAYICI_KURAL, use_judge=False)
        tarih = asyncio.run(ajan.run(max_steps=30))
        sonuc = {'sonuc': (tarih.final_result() or 'Sonuç çıkmadı.').strip()}
    except Exception as e:
        sonuc = {'sonuc': 'Tarayıcı ajanı hata verdi: ' + repr(e)[:300]}
    json.dump(sonuc, open(cikti, 'w', encoding='utf-8'), ensure_ascii=False)


ARACLAR = [
    {'name': 'hafiza_ara', 'description': "Kullanıcının klasöründeki tüm notlarda, belgelerde ve geçmiş konuşmalarınızda hem kelimeyle hem anlamıyla arar; en alakalı 5 kısa parçayı döner. Geçmişte konuşulan bir şey, bir kişi/proje ya da kullanıcıya ait bilgi sorulunca ÖNCE bunu kullan.",
     'parameters': {'type': 'OBJECT', 'properties': {'soru': {'type': 'STRING'}}, 'required': ['soru']}},
    {'name': 'hafizaya_yaz', 'description': "Kullanıcı 'bunu hatırla', 'unutma' dediğinde ya da kalıcı bir tercih/bilgi söylediğinde HAFIZA.md'ye tek satır olarak ekler.",
     'parameters': {'type': 'OBJECT', 'properties': {'metin': {'type': 'STRING'}}, 'required': ['metin']}},
    {'name': 'not_al', 'description': "Kullanıcının söylediği yapılacak işi ya da notu NOTLAR.md'ye ekler.",
     'parameters': {'type': 'OBJECT', 'properties': {'metin': {'type': 'STRING'}}, 'required': ['metin']}},
    {'name': 'youtube_ara', 'description': "YouTube'da anlık arama: video başlığı, kanal, izlenme, yayın zamanı. Canlı YouTube verisi sorulunca kullan.",
     'parameters': {'type': 'OBJECT', 'properties': {'sorgu': {'type': 'STRING'}}, 'required': ['sorgu']}},
    {'name': 'web_oku', 'description': 'Verilen web sayfasını açıp metnini okur. Önce Google aramasıyla adresi bul, sonra bununla oku.',
     'parameters': {'type': 'OBJECT', 'properties': {'url': {'type': 'STRING'}}, 'required': ['url']}},
    {'name': 'ekran_bak', 'description': "Mac ekranının o anki görüntüsünü alır ve ekranda ne olduğunu yazılı verir. SADECE kullanıcı açıkça ekrandan söz ettiğinde kullan. Görüntü kaydedilmez.",
     'parameters': {'type': 'OBJECT', 'properties': {'neden': {'type': 'STRING'}}}},
    {'name': 'tarayici_gorev', 'description': "Ayrı bir tarayıcı açıp internette çok adımlı bir işi kendi başına yapar (siteleri gezip bilgi toplar, karşılaştırır, liste çıkarır). Birkaç dakika sürer, arka planda çalışır. Form göndermez, satın almaz, giriş yapmaz.",
     'parameters': {'type': 'OBJECT', 'properties': {'gorev': {'type': 'STRING'}}, 'required': ['gorev']}},
    {'name': 'tarayici_durum', 'description': 'Başlatılan tarayıcı görevlerinin durumu ve sonucu.', 'parameters': {'type': 'OBJECT', 'properties': {}}},
]


def arac_isle(f):
    a = f.get('args') or {}; ad = f.get('name')
    try:
        if ad == 'hafiza_ara':
            return HAFIZA.ara(str(a.get('soru') or '')[:300]) if HAFIZA else {'hata': 'Hafıza araması henüz hazır değil.'}
        if ad == 'hafizaya_yaz':
            hafizaya_ekle(str(a.get('metin') or '')); return {'durum': 'Hafızaya yazıldı.'}
        if ad == 'not_al':
            not_ekle(str(a.get('metin') or '')); return {'durum': 'Not alındı.'}
        if ad == 'youtube_ara':
            return youtube_ara(str(a.get('sorgu') or '')[:200])
        if ad == 'web_oku':
            return web_oku(str(a.get('url') or ''))
        if ad == 'ekran_bak':
            return {'ekranda': ekran_yorumla(str(a.get('neden') or ''))}
        if ad == 'tarayici_gorev':
            return tarayici_baslat(str(a.get('gorev') or '')[:1500])
        if ad == 'tarayici_durum':
            return tarayici_durum()
        return {'hata': 'Bilinmeyen araç.'}
    except Exception as e:
        return {'hata': 'Yapılamadı: ' + str(e)[:120]}


# ------------------------------------------------------------------ ses: mikrofon, hoparlör, yankı engelleme
class Mikrofon:
    def __init__(self):
        import sounddevice as sd
        self.q = queue.Queue()
        self.akis = sd.InputStream(samplerate=ORAN, channels=1, dtype='int16', blocksize=KARE, callback=lambda i, f, t, s: self.q.put(i[:, 0].copy()))
        self.akis.start()

    def oku(self, zaman_asimi=None):
        return self.q.get(timeout=zaman_asimi)

    def bosalt(self):
        try:
            while True:
                self.q.get_nowait()
        except queue.Empty:
            pass


class Hoparlor:
    """24 kHz sesi çalar (yankı engelleme yoksa kullanılır)."""
    def __init__(self):
        import sounddevice as sd
        self.buf = bytearray(); self.kilit = threading.Lock(); self.son = 0.0
        self.akis = sd.OutputStream(samplerate=24000, channels=1, dtype='int16', blocksize=960, callback=self._cb)
        self.akis.start()

    def _cb(self, outdata, frames, t, status):
        n = frames * 2
        with self.kilit:
            parca = bytes(self.buf[:n]); del self.buf[:n]
            if parca:
                self.son = time.time()
        outdata[:, 0] = np.frombuffer(parca + b'\x00' * (n - len(parca)), dtype=np.int16)

    def ekle(self, b):
        with self.kilit:
            self.buf += b

    def temizle(self):
        with self.kilit:
            self.buf = bytearray()

    def caliyor(self):
        with self.kilit:
            dolu = len(self.buf) > 0
        return dolu or time.time() - self.son < 0.35

    def kapat(self):
        try:
            self.akis.stop(); self.akis.close()
        except Exception:
            pass


class Duplex(Hoparlor):
    """Mikrofon + hoparlör tek akışta (16 kHz); mikrofon WebRTC ses işlemeden (yankı engelleme, gürültü bastırma,
    otomatik ses seviyesi — Chrome'unkiyle aynı) geçer. Jarvis konuşurken araya girebilirsin."""
    def __init__(self):
        import sounddevice as sd
        import pywebrtc_audio as pw
        try:
            self.ec = pw.AudioProcessor(16000, 1, echo_cancellation=True, noise_suppression=True, high_pass_filter=True, auto_gain_control=True, ns_level=2)
        except Exception:
            self.ec = pw.EchoCanceller(16000, 1)
        self.q = queue.Queue(); self.buf = bytearray(); self.kilit = threading.Lock(); self.son = 0.0; self.kalan = np.zeros(0, np.float32)
        self.akis = sd.Stream(samplerate=16000, channels=1, dtype='int16', blocksize=KARE, callback=self._cb2)
        self.akis.start()

    def _cb2(self, indata, outdata, frames, t, status):
        n = frames * 2
        with self.kilit:
            parca = bytes(self.buf[:n]); del self.buf[:n]
            if parca:
                self.son = time.time()
        uzak = np.frombuffer(parca + b'\x00' * (n - len(parca)), dtype=np.int16)
        outdata[:, 0] = uzak
        yakin = np.ascontiguousarray(indata[:, 0], dtype=np.int16)
        try:
            temiz = np.asarray(self.ec.process(yakin, uzak), dtype=np.int16)
        except Exception:
            temiz = yakin.copy()
        self.q.put(temiz)

    def ekle(self, b):   # 24 kHz -> 16 kHz
        x = np.concatenate([self.kalan, np.frombuffer(b, dtype=np.int16).astype(np.float32)])
        n = int(len(x) * 2 // 3)
        if n < 2:
            self.kalan = x; return
        konum = np.arange(n) * 1.5
        y = np.interp(konum, np.arange(len(x)), x)
        self.kalan = x[int(konum[-1]) + 1:]
        with self.kilit:
            self.buf += np.clip(y, -32768, 32767).astype(np.int16).tobytes()

    def temizle(self):
        super().temizle(); self.kalan = np.zeros(0, np.float32)

    def oku(self, zaman_asimi=None):
        return self.q.get(timeout=zaman_asimi)


# ------------------------------------------------------------------ canlı konuşma (Gemini Live)
KAPAN = re.compile(r'(kapanabilirsin|kapan art[ıi]k|kapan jarvis|jarvis kapan|kendini kapat|uyuyabilirsin|uyu (sen|art[ıi]k|jarvis)|sen uyu|[şs]imdilik bu kadar|bu kadar yeter|g[öo]r[üu][şs][üu]r[üu]z|ho[şs][çc]a kal|bay bay|sus art[ıi]k)')
VEDA = re.compile(r'g[öo]r[üu][şs][üu]r[üu]z', re.I)
SON_KONUSMA = []   # (zaman, ben, jarvis): oturumlar arası kısa hafıza


def sistem_metni():
    kimlik = oku(os.path.join(KLASOR, 'KIMLIK.md'), 10000)
    hafiza = oku(os.path.join(KLASOR, 'HAFIZA.md'))
    if len(hafiza) > 10000:
        hafiza = hafiza[:3000] + '\n…\n' + hafiza[-7000:]
    notlar = oku(os.path.join(KLASOR, 'NOTLAR.md'))[-4000:]
    bugun = oku(os.path.join(KONUSMA_KLASOR, datetime.date.today().isoformat() + '.md'))[-6000:]
    simdi = datetime.datetime.now()
    gunler = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar']
    p = ["Sen Jarvis'sin, kişisel sesli asistansın. Konuştuğun kişinin adı: " + A['kullanici_adi'] + ". Mac'in hoparlöründen sesli konuşuyorsunuz; ekran yok.",
         'Şu an: ' + simdi.strftime('%d.%m.%Y %H:%M') + ' ' + gunler[simdi.weekday()] + '.',
         'Kısa, doğal ve sıcak konuş; gereksiz uzatma. Bilmediğini uydurma; güncel bilgi için Google araması yap.',
         "Kullanıcı hep Türkçe konuşur, sen de Türkçe cevap ver. Arka plandaki başka insanların sesleri, TV, yarım ya da anlamsız ya da başka dilde algılanan sesler gürültüdür: cevap verme.",
         "Bir kelimeyi (özellikle isim) tam anlamadıysan tahmin etmek yerine kısaca 'X mi dedin?' diye sor.",
         "Geçmiş konuşmalar, kişiler, projeler sorulunca önce hafiza_ara kullan. 'Bunu hatırla' denince hafizaya_yaz, yapılacak iş söylenince not_al.",
         "Ekrana sadece kullanıcı açıkça isterse bak (ekran_bak). İnternette çok adımlı bir iş istenirse tarayici_gorev.",
         "Kullanıcı 'kapanabilirsin', 'uyu', 'görüşürüz' derse sadece kısaca 'Görüşürüz' de."]
    if kimlik:
        p.append('\nKİMLİĞİN VE KULLANICI HAKKINDA BİLDİKLERİN (KIMLIK.md; bu kişilikle konuş):\n' + kimlik)
    if hafiza:
        p.append('\nHAFIZA (HAFIZA.md):\n' + hafiza)
    if notlar:
        p.append('\nNOTLAR (son):\n' + notlar)
    if bugun:
        p.append('\nBUGÜNKÜ KONUŞMALAR (son):\n' + bugun)
    son = [h for h in SON_KONUSMA if time.time() - h[0] < 3600]
    if son:
        p.append('\nAZ ÖNCEKİ KONUŞMA:\n' + '\n'.join('Kullanıcı: ' + b + '\nSen: ' + o for _, b, o in son[-8:]))
    return '\n'.join(p)


def canli_oturum(mik, vad, sessiz=False):
    """Uyanınca açılır. True: oturum oldu; 'koptu': yeniden bağlanmalı; False: açılamadı."""
    from websockets.sync.client import connect
    calan = threading.Thread(target=(lambda: None) if sessiz else (lambda: say(A['selam'])), daemon=True)
    calan.start()
    try:
        ws = connect(CANLI_WS + '?key=' + urllib.parse.quote(anahtar(), safe=''), open_timeout=10, max_size=None)
    except Exception as e:
        log('bağlantı açılamadı: ' + str(e)[:150]); calan.join(); return False
    setup = {'model': A['canli_model'],
             'generationConfig': {'responseModalities': ['AUDIO'], 'speechConfig': {'voiceConfig': {'prebuiltVoiceConfig': {'voiceName': A['ses']}}}},
             'systemInstruction': {'parts': [{'text': sistem_metni()}]},
             'tools': [{'googleSearch': {}}, {'functionDeclarations': ARACLAR}],
             'inputAudioTranscription': {}, 'outputAudioTranscription': {},
             'contextWindowCompression': {'slidingWindow': {}},
             'realtimeInputConfig': {'automaticActivityDetection': {'startOfSpeechSensitivity': 'START_SENSITIVITY_LOW', 'prefixPaddingMs': 200, 'silenceDurationMs': 700}}}
    ws.send(json.dumps({'setup': setup}))
    ses = None
    if A['yanki_engelleme']:
        try:
            ses = Duplex()
        except Exception as e:
            log('yankı engelleme açılamadı (' + str(e)[:80] + ')')
    hop = ses or Hoparlor()
    d = {'hazir': threading.Event(), 'bitti': False, 'son': time.time(), 'bekliyor': False, 'ben': '', 'o': ''}

    def alici():
        try:
            for ham in ws:
                m = json.loads(ham if isinstance(ham, str) else ham.decode())
                if 'setupComplete' in m:
                    d['hazir'].set(); continue
                tc = m.get('toolCall')
                if tc:
                    def isle(tc=tc):
                        cev = [{'id': f.get('id'), 'name': f.get('name'), 'response': arac_isle(f)} for f in tc.get('functionCalls') or []]
                        log('araç: ' + ', '.join(f.get('name') or '' for f in tc.get('functionCalls') or []))
                        try:
                            ws.send(json.dumps({'toolResponse': {'functionResponses': cev}}))
                        except Exception:
                            pass
                    threading.Thread(target=isle, daemon=True).start()
                sc = m.get('serverContent') or {}
                if sc:
                    d['son'] = time.time()
                if sc.get('interrupted'):
                    hop.temizle()
                it = (sc.get('inputTranscription') or {}).get('text')
                if it:
                    d['ben'] += it; d['bekliyor'] = True; d['soruldu'] = True
                    if not d.get('kapat') and KAPAN.search(tr_kucuk(d['ben'])):
                        d['kapat'] = time.time()
                ot = (sc.get('outputTranscription') or {}).get('text')
                if ot:
                    d['o'] += ot
                    if not d.get('kapat') and VEDA.search(d['o']):
                        d['kapat'] = time.time()
                for pr in ((sc.get('modelTurn') or {}).get('parts') or []):
                    v = (pr.get('inlineData') or {}).get('data')
                    if v:
                        hop.ekle(base64.b64decode(v))
                if sc.get('turnComplete'):
                    d['bekliyor'] = False
                    if d['ben'].strip() or d['o'].strip():
                        log('SORU: ' + d['ben'].strip()[:150]); log('CEVAP: ' + d['o'].strip()[:150])
                        SON_KONUSMA.append((time.time(), d['ben'].strip()[:400], d['o'].strip()[:400])); del SON_KONUSMA[:-12]
                        konusma_yaz(d['ben'], d['o'])
                    d['ben'] = d['o'] = ''
                if m.get('goAway'):
                    break
        except Exception as e:
            if not d['bitti']:
                log('bağlantı kapandı: ' + str(e)[:120]); d['koptu'] = True
        d['bitti'] = True

    threading.Thread(target=alici, daemon=True).start()
    t0 = time.time()
    while not d['hazir'].is_set() and not d['bitti'] and time.time() - t0 < 10:
        d['hazir'].wait(0.2)
    calan.join()
    if not d['hazir'].is_set():
        log('canlı oturum kurulamadı (anahtar ya da model adı hatalı olabilir)'); d['bitti'] = True
        try:
            ws.close()
        except Exception:
            pass
        hop.kapat(); return False
    mik.bosalt()
    try:
        vad.reset_states()
    except Exception:
        pass
    d['son'] = d['acilis'] = time.time()
    log('oturum açık' + (' (yankı engelleme açık)' if ses else ''))
    try:
        while not d['bitti']:
            try:
                k = (ses or mik).oku(0.5)
            except queue.Empty:
                k = None
            if ses:
                mik.bosalt()
            if k is not None:
                try:
                    p_ = float(vad.predict(k, frame_size=640))
                except Exception:
                    p_ = 0.0
                if ses:
                    gonder = k if (not hop.caliyor() or p_ >= 0.6) else np.zeros_like(k)
                else:
                    gonder = None if hop.caliyor() else k
                if gonder is not None:
                    ws.send(json.dumps({'realtimeInput': {'audio': {'data': base64.b64encode(gonder.tobytes()).decode(), 'mimeType': 'audio/pcm;rate=16000'}}}))
                if p_ >= 0.5:
                    d['son'] = time.time()
            if hop.caliyor():
                d['son'] = time.time()
            if not d['bekliyor'] and time.time() - d['son'] > A['kapanma_sn']:
                break
            if not d.get('soruldu') and not d['bekliyor'] and time.time() - d['acilis'] > A['ilk_soru_sn'] and not hop.caliyor():
                break
            if d['bekliyor'] and time.time() - d['son'] > 25:
                break
            if d.get('kapat') and not hop.caliyor() and (not d['bekliyor'] or time.time() - d['kapat'] > 4):
                break
    finally:
        d['bitti'] = True
        try:
            ws.close()
        except Exception:
            pass
        t1 = time.time()
        while hop.caliyor() and time.time() - t1 < 20:
            time.sleep(0.1)
        hop.kapat()
        if d.get('koptu') and not d.get('kapat'):
            return 'koptu'
        bip('Bottle')
        log('oturum kapandı; "Hey Jarvis" bekleniyor')
    return True


# ------------------------------------------------------------------ uyandırma ve ana döngü
def model_yukle():
    from openwakeword.model import Model
    if os.path.exists(DOGRULAYICI):
        try:
            m = Model(wakeword_models=['hey_jarvis'], inference_framework='onnx',
                      custom_verifier_models={'hey_jarvis': DOGRULAYICI}, custom_verifier_threshold=A['on_esik'])
            log('sana özel doğrulayıcı açık')
            return m
        except Exception as e:
            log('doğrulayıcı yüklenemedi: ' + str(e)[:100])
    return Model(wakeword_models=['hey_jarvis'], inference_framework='onnx')


def main():
    if not anahtar():
        log('Gemini anahtarı yok: ~/.jarvis-asistan/gemini.key'); time.sleep(60); return
    from openwakeword.vad import VAD
    model, vad = model_yukle(), VAD()
    threading.Thread(target=hafiza_dongu, daemon=True).start()
    mik = Mikrofon()
    surum = os.path.getmtime(os.path.abspath(__file__))
    log('hazır; "Hey Jarvis" bekleniyor (eşik %.2f)' % A['uyanma_esigi'])
    sayac = 0
    while True:
        k = mik.oku()
        sayac += 1
        if sayac % 60 == 0 and (os.path.exists(KAPALI) or os.path.getmtime(os.path.abspath(__file__)) != surum):
            log('yeniden başlıyorum'); raise SystemExit(0)
        skor = max(model.predict(k).values() or [0])
        if skor < A['uyanma_esigi']:
            continue
        log('uyandı (skor %.2f)' % skor)
        try:
            sonuc, deneme = canli_oturum(mik, vad), 0
            while sonuc == 'koptu' and deneme < 2:
                deneme += 1; sonuc = canli_oturum(mik, vad, sessiz=True)
            if not sonuc:
                say('Şu an bağlanamıyorum.')
        except Exception as e:
            log('oturum hatası: ' + repr(e)[:200])
        mik.bosalt(); model.reset()


def tanit():
    """'Hey Jarvis'i senin sesinle eğitir: 10 kez söylersin, 25 sn normal konuşursun, 10 sn sessizlik."""
    import sounddevice as sd, scipy.io.wavfile as wf, pickle
    from openwakeword.model import Model
    from openwakeword.custom_verifier_model import get_reference_clip_features, train_verifier_model
    kl = os.path.join(EV, 'tanitim'); pos = os.path.join(kl, 'pozitif'); neg = os.path.join(kl, 'negatif')
    os.makedirs(pos, exist_ok=True); os.makedirs(neg, exist_ok=True)
    for f in glob.glob(os.path.join(pos, '*.wav')) + glob.glob(os.path.join(neg, '*.wav')):
        os.remove(f)
    open(KAPALI, 'w').close()          # tanıtım sırasında arka plan servisi uyanmasın
    try:
        oww = Model(wakeword_models=['hey_jarvis'], inference_framework='onnx')

        def skor(x):
            oww.reset(); m = 0.0
            for j in range(0, len(x) - KARE, KARE):
                m = max(m, float(oww.predict(x[j:j + KARE])['hey_jarvis']))
            return m
        print('\n=== Hey Jarvis tanıtımı (yaklaşık 2 dakika) ===\nMac\'in önünde, normalde konuştuğun mesafede dur.\n')
        i = 0
        while i < 10:
            input('[%d/10] Enter\'a bas; "bip" sesini DUYDUKTAN SONRA "Hey Jarvis" de… ' % (i + 1))
            x = sd.rec(int(3.2 * ORAN), samplerate=ORAN, channels=1, dtype='int16'); bip(); sd.wait()
            x = x[int(0.45 * ORAN):, 0]
            sk = skor(x)
            if sk < 0.1:
                print('   duyamadım (tanıma %.2f) — bipten sonra biraz daha yüksek sesle tekrar.' % sk); continue
            wf.write(os.path.join(pos, 'hey_%02d.wav' % i), ORAN, x); print('   alındı (tanıma %.2f)' % sk); i += 1
        for ad, sure, mesaj in (('konusma', 25, 'Enter\'a bas, bipten sonra 25 saniye normal konuş ("Hey Jarvis" deme)… '),
                                ('ortam', 10, 'Son adım: Enter\'a bas, 10 saniye hiç konuşma… ')):
            input('\n' + mesaj)
            x = sd.rec(int(sure * ORAN), samplerate=ORAN, channels=1, dtype='int16'); bip(); sd.wait()
            x = x[int(0.3 * ORAN):, 0]
            for j in range(0, len(x) - 2 * ORAN, 2 * ORAN):
                wf.write(os.path.join(neg, '%s_%02d.wav' % (ad, j // (2 * ORAN))), ORAN, x[j:j + 2 * ORAN])
        print('\nModel eğitiliyor…')
        pf = []
        for f in sorted(glob.glob(os.path.join(pos, '*.wav'))):
            oww.reset(); ff = get_reference_clip_features(f, oww, 'hey_jarvis', threshold=0.15, N=5)
            if ff.shape[0]:
                pf.append(ff)
        nf = []
        for f in sorted(glob.glob(os.path.join(neg, '*.wav'))):
            oww.reset(); nf.append(get_reference_clip_features(f, oww, 'hey_jarvis', threshold=0.0, N=1))
        if len(pf) < 4:
            print('Yetersiz kayıt; tekrar dene.'); return 1
        X = np.vstack(pf + nf); y = np.array([1] * sum(len(a) for a in pf) + [0] * sum(len(a) for a in nf))
        pickle.dump(train_verifier_model(X, y), open(DOGRULAYICI, 'wb'))
        print('Tamam: sana özel doğrulayıcı kaydedildi.')
        return 0
    finally:
        try:
            os.remove(KAPALI)
        except OSError:
            pass


def test():
    import sounddevice as sd
    print('Mikrofon: 3 saniye konuş…')
    x = sd.rec(3 * ORAN, samplerate=ORAN, channels=1, dtype='int16'); sd.wait()
    print('  ses seviyesi: %.3f %s' % (rms(x[:, 0]), '(iyi)' if rms(x[:, 0]) > 0.01 else '(çok düşük — mikrofon izni ya da cihaz?)'))
    print('Gemini anahtarı: ' + ('var' if anahtar() else 'YOK (~/.jarvis-asistan/gemini.key)'))
    try:
        print('Gemini cevabı: ' + gemini_metin([{'text': 'Sadece "çalışıyor" yaz.'}], 30))
    except Exception as e:
        print('Gemini hatası: ' + str(e))


if __name__ == '__main__':
    if '--tanit' in sys.argv:
        sys.exit(tanit())
    if '--test' in sys.argv:
        test(); sys.exit(0)
    if '--hafiza-kur' in sys.argv:
        h = Hafiza(); h.guncelle(); print('hafıza dizini hazır: %d parça' % len(h.parcalar)); sys.exit(0)
    if '--tarayici' in sys.argv:
        i = sys.argv.index('--tarayici'); tarayici_isci(sys.argv[i + 1], sys.argv[i + 2]); sys.exit(0)
    while True:
        while os.path.exists(KAPALI):
            time.sleep(15)
        try:
            main()
        except SystemExit:
            raise
        except KeyboardInterrupt:
            break
        except Exception as e:
            log('çöktü, 10 sn sonra yeniden: ' + repr(e)); time.sleep(10)
