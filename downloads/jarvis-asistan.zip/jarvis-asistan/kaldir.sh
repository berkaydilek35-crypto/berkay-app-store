#!/bin/bash
# Jarvis'i durdurur ve kaldırır. Notların ve konuşma dökümlerin (Jarvis klasörü) silinmez.
PL="$HOME/Library/LaunchAgents/com.jarvis-asistan.plist"
launchctl bootout "gui/$(id -u)" "$PL" 2>/dev/null || true
rm -f "$PL"
rm -rf "$HOME/.jarvis-asistan"
echo "Jarvis kaldırıldı. Notların ve konuşmaların Jarvis klasöründe duruyor; istersen elle silebilirsin."
