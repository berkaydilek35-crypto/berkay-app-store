# Acaba?

Acaba dediğin her şeyin en enteresan cevabı. Aklına takılanı yaz ("Acaba yarın Barcelona maçında bize ne yapacaklar?"), cevabını komik bir kart ve 17 saniyelik dikey video olarak izle.

Berkay Dilek (@berkay.builds) yaptı — Saha Testi 001. Canlı sürüm: https://berkay.instaassist.tr

## Nasıl kullanılır?

1. ZIP dosyasını aç (çift tıkla).
2. `acaba` klasöründeki `index.html` dosyasını Chrome, Safari ya da Edge ile aç.
3. Aklındakini yaz, "ACABA?" butonuna bas. Kartı ve videoyu indirip paylaşabilirsin.

İnternet gerekmez: yazı tipleri dahil her şey bu tek dosyanın içinde. Yazdığın metin cihazından çıkmaz, kayıt veya hesap yok.

## Kendi sitende yayınla

Klasörü olduğu gibi herhangi bir web sunucusuna (GitHub Pages, Netlify, Cloudflare Pages, kendi hostingin) yükle. HTTPS altında açılınca telefonda "Ana ekrana ekle" ile uygulama gibi kurulabilir.

`index.html` içindeki `CONFIG` bölümünden kartta ve videoda görünen adresi (`site`) değiştirebilirsin.

## İsteğe bağlı: yapay zekâ modu

Ayarlar (⚙️) bölümünden kendi API anahtarını girersen senaryoyu yapay zekâ yazar. Anahtar yalnızca senin tarayıcında saklanır. Anahtar girmezsen uygulama çevrimdışı motorla, ücretsiz çalışır.

## Lisans

Kod: MIT (LICENSE). Yazı tipleri Anton ve Barlow: SIL Open Font License 1.1 (fonts/ klasörü).
