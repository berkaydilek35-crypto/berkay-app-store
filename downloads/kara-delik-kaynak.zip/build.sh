#!/bin/bash
# Kara Delik — derleme betiği. Kullanım: bash build.sh
set -euo pipefail
cd "$(dirname "$0")"

APP="build/Kara Delik.app"
ARCH="$(uname -m)"

echo "▶ Derleniyor ($ARCH)…"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"

compile() {
  xcrun --sdk macosx swiftc -swift-version 5 -O \
    -target "$1-apple-macos13.0" \
    -o "$2" \
    Sources/*.swift \
    -framework AppKit -framework SpriteKit -framework QuickLookThumbnailing
}

if [ "${UNIVERSAL:-0}" = "1" ]; then
  # Hem Apple Silicon hem Intel Mac'lerde çalışsın
  compile arm64 build/KaraDelik-arm64
  compile x86_64 build/KaraDelik-x86_64
  lipo -create -output "$APP/Contents/MacOS/KaraDelik" build/KaraDelik-arm64 build/KaraDelik-x86_64
  rm -f build/KaraDelik-arm64 build/KaraDelik-x86_64
else
  compile "$ARCH" "$APP/Contents/MacOS/KaraDelik"
fi

cp Resources/*.wav "$APP/Contents/Resources/"

if [ -f Resources/AppIcon.png ]; then
  echo "▶ İkon hazırlanıyor…"
  ICONSET="build/AppIcon.iconset"
  rm -rf "$ICONSET"; mkdir -p "$ICONSET"
  for s in 16 32 128 256 512; do
    sips -z $s $s Resources/AppIcon.png --out "$ICONSET/icon_${s}x${s}.png" >/dev/null
    sips -z $((s*2)) $((s*2)) Resources/AppIcon.png --out "$ICONSET/icon_${s}x${s}@2x.png" >/dev/null
  done
  iconutil -c icns "$ICONSET" -o "$APP/Contents/Resources/AppIcon.icns"
fi

cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>Kara Delik</string>
  <key>CFBundleDisplayName</key><string>Kara Delik</string>
  <key>CFBundleIdentifier</key><string>com.berkaybuilds.karadelik</string>
  <key>CFBundleExecutable</key><string>KaraDelik</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>1.0</string>
  <key>CFBundleVersion</key><string>1</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>CFBundleDevelopmentRegion</key><string>tr</string>
  <key>LSMinimumSystemVersion</key><string>13.0</string>
  <key>LSUIElement</key><true/>
  <key>NSHumanReadableCopyright</key><string>© 2026 Berkay Dilek · @berkay.builds · MIT</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>NSAppleEventsUsageDescription</key><string>Çöp Sepeti'ni boşaltmak için Finder'a komut gönderir.</string>
</dict>
</plist>
PLIST

codesign --force --deep --sign - "$APP" >/dev/null 2>&1 || true
echo "✅ Hazır: $APP"
