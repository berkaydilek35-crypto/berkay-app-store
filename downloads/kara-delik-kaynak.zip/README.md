# Kara Delik 🕳️

Masaüstünde bir kara delik. İçine attığın her şey sarmal çizerek, uzayıp incelerek içeri çekilir ve **gerçek Çöp Sepeti'ne** gider (kalıcı silinmez, geri alınabilir).

## Çalıştır

```bash
cd ~/Projeler/kara-delik
bash dev.sh
```

Uygulama: `build/Kara Delik.app` (istersen Uygulamalar klasörüne sürükle).

İndirme paketi (Intel + Apple Silicon): `bash dev.sh build` → `release/`. Site: https://berkay.instaassist.tr/kara-delik

## Kullanım

- **Dosya at:** Masaüstünden ya da Finder'dan sürükle, deliğe bırak.
- **Taşı:** Deliği tutup sürükle.
- **Tek tık:** Dürt. **Çift tık:** Çöp Sepeti'ni aç.
- **Sağ tık / menü çubuğu ikonu:** Ayarlar, Çöp Sepeti'ni boşalt (buharlaşma animasyonu), boyut, ses.
- Yuttukça büyür. "Kara Deliği Küçült" sayacı sıfırlar.

## Güvenlik

- Dosyalar sadece Çöp Sepeti'ne taşınır (`NSWorkspace.recycle`).
- Ana klasörler (Masaüstü, Belgeler, İndirilenler, Uygulamalar, sistem) yutulmaz.
- Çöp Sepeti'ni boşaltmak onay ister.

## Yapı

| Dosya | Ne yapar |
|---|---|
| `Sources/Shader.swift` | Kara delik görüntüsü (olay ufku, foton halkası, disk, ışık bükme) |
| `Sources/HoleScene.swift` | Yutma animasyonu, spagettileşme, buharlaşma |
| `Sources/HoleView.swift` | Sürükle-bırak ve fare |
| `Sources/AppDelegate.swift` | Pencere, menü, Çöp Sepeti işlemleri |
| `Sources/Wallpaper.swift` | Deliğin arkasındaki duvar kâğıdı parçası |
