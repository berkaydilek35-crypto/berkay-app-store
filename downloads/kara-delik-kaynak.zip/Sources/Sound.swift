import AppKit

enum Sound {
    /// Çalan sesleri bitene kadar hafızada tut.
    private static var playing: [NSSound] = []

    static func play(_ name: String, volume: Float = 0.9) {
        guard Settings.soundOn,
              let url = Bundle.main.url(forResource: name, withExtension: "wav"),
              let s = NSSound(contentsOf: url, byReference: true) else { return }
        playing.removeAll { !$0.isPlaying }
        s.volume = volume
        playing.append(s)
        s.play()
    }
}
