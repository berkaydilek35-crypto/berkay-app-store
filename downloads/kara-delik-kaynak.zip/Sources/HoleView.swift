import AppKit
import SpriteKit

protocol HoleViewDelegate: AnyObject {
    func holeView(_ view: HoleView, didReceive urls: [URL], at point: NSPoint)
    func holeViewDoubleClicked(_ view: HoleView)
    func holeViewWillMove(_ view: HoleView)
    func holeViewMenu(_ view: HoleView) -> NSMenu
}

/// Kara deliğin çizildiği ve dosyaların bırakıldığı görünüm.
final class HoleView: SKView {
    weak var holeDelegate: HoleViewDelegate?
    private var holeScene: HoleScene? { scene as? HoleScene }
    private var mouseDownPoint: NSPoint = .zero
    private var movingWindow = false

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        allowsTransparency = true
        ignoresSiblingOrder = true
        preferredFramesPerSecond = 60
        registerForDraggedTypes([.fileURL])
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) kullanılmıyor") }

    // MARK: - Sürükle bırak

    private func fileURLs(from info: NSDraggingInfo) -> [URL] {
        let opts: [NSPasteboard.ReadingOptionKey: Any] = [.urlReadingFileURLsOnly: true]
        return (info.draggingPasteboard.readObjects(forClasses: [NSURL.self], options: opts) as? [URL]) ?? []
    }

    /// İmleç deliğe yaklaştıkça çekim artar.
    private func attraction(for info: NSDraggingInfo) -> CGFloat {
        let p = convert(info.draggingLocation, from: nil)
        let d = hypot(p.x - bounds.midX, p.y - bounds.midY)
        let zone = bounds.width * 0.42
        return max(0.3, min(1, 1.25 - d / zone))
    }

    override func draggingEntered(_ sender: NSDraggingInfo) -> NSDragOperation {
        guard !fileURLs(from: sender).isEmpty else { return [] }
        holeScene?.setAttraction(attraction(for: sender))
        return .generic
    }

    override func draggingUpdated(_ sender: NSDraggingInfo) -> NSDragOperation {
        guard !fileURLs(from: sender).isEmpty else { return [] }
        holeScene?.setAttraction(attraction(for: sender))
        return .generic
    }

    override func draggingExited(_ sender: NSDraggingInfo?) {
        holeScene?.setAttraction(0)
    }

    override func draggingEnded(_ sender: NSDraggingInfo) {
        holeScene?.setAttraction(0)
    }

    override func prepareForDragOperation(_ sender: NSDraggingInfo) -> Bool { true }

    override func performDragOperation(_ sender: NSDraggingInfo) -> Bool {
        let urls = fileURLs(from: sender)
        guard !urls.isEmpty else { return false }
        let p = convert(sender.draggingLocation, from: nil)
        holeDelegate?.holeView(self, didReceive: urls, at: p)
        return true
    }

    // MARK: - Fare

    override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }

    override func mouseDown(with event: NSEvent) {
        mouseDownPoint = event.locationInWindow
        movingWindow = false
        if event.clickCount == 2 {
            holeDelegate?.holeViewDoubleClicked(self)
        }
    }

    override func mouseDragged(with event: NSEvent) {
        guard !movingWindow else { return }
        let p = event.locationInWindow
        if hypot(p.x - mouseDownPoint.x, p.y - mouseDownPoint.y) > 3 {
            movingWindow = true
            holeDelegate?.holeViewWillMove(self)
            window?.performDrag(with: event)
        }
    }

    override func mouseUp(with event: NSEvent) {
        if !movingWindow && event.clickCount == 1 {
            holeScene?.poke()
            Sound.play("poke", volume: 0.5)
        }
        movingWindow = false
    }

    override func rightMouseDown(with event: NSEvent) {
        guard let menu = holeDelegate?.holeViewMenu(self) else { return }
        NSMenu.popUpContextMenu(menu, with: event, for: self)
    }
}
