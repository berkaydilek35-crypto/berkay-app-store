import AppKit

/// Kalıcı ayarlar (UserDefaults).
enum Settings {
    private static var d: UserDefaults { UserDefaults.standard }

    static var alwaysOnTop: Bool {
        get { d.object(forKey: "alwaysOnTop") as? Bool ?? false }
        set { d.set(newValue, forKey: "alwaysOnTop") }
    }

    static var soundOn: Bool {
        get { d.object(forKey: "soundOn") as? Bool ?? true }
        set { d.set(newValue, forKey: "soundOn") }
    }

    /// Duvar kâğıdını bükme (kütleçekimsel mercek) efekti.
    static var lensingOn: Bool {
        get { d.object(forKey: "lensingOn") as? Bool ?? false }
        set { d.set(newValue, forKey: "lensingOn") }
    }

    /// 0 = küçük, 1 = orta, 2 = büyük
    static var sizeLevel: Int {
        get { d.object(forKey: "sizeLevel") as? Int ?? 1 }
        set { d.set(newValue, forKey: "sizeLevel") }
    }

    static var eatenBytes: Double {
        get { d.double(forKey: "eatenBytes") }
        set { d.set(newValue, forKey: "eatenBytes") }
    }

    static var eatenCount: Int {
        get { d.integer(forKey: "eatenCount") }
        set { d.set(newValue, forKey: "eatenCount") }
    }

    /// Kara deliğin ekrandaki merkezi.
    static var center: NSPoint? {
        get {
            guard let s = d.string(forKey: "center") else { return nil }
            return NSPointFromString(s)
        }
        set {
            if let p = newValue {
                d.set(NSStringFromPoint(p), forKey: "center")
            } else {
                d.removeObject(forKey: "center")
            }
        }
    }

    static var baseSize: CGFloat {
        switch sizeLevel {
        case 0: return 150
        case 2: return 280
        default: return 200
        }
    }

    /// Kara delik yuttukça büyür: 10 MB ≈ %12, 1 GB ≈ %36, 10 GB ≈ %48 (en fazla %50).
    static var growth: CGFloat {
        let mb = max(0, eatenBytes) / 1_000_000
        return 1 + min(0.5, 0.12 * CGFloat(log10(1 + mb)))
    }

    static var holeSize: CGFloat { (baseSize * growth).rounded() }
}
