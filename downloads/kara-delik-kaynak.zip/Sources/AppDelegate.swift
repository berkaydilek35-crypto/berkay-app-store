import AppKit
import SpriteKit
import QuickLookThumbnailing
import UniformTypeIdentifiers

/// Birden fazla tetiklenebilecek bir işi tek sefer çalıştırmak için.
private final class Once {
    var done = false
}

final class AppDelegate: NSObject, NSApplicationDelegate, NSMenuDelegate, HoleViewDelegate {
    private var window: NSWindow!
    private var holeView: HoleView!
    private var scene: HoleScene!
    private var statusItem: NSStatusItem!
    private var mouseTimer: Timer?
    private let lensQueue = DispatchQueue(label: "karadelik.lens", qos: .userInitiated)
    private var lensGeneration = 0

    // MARK: - Açılış

    func applicationDidFinishLaunching(_ notification: Notification) {
        if anotherInstanceIsRunning() {
            NSApp.terminate(nil)
            return
        }
        buildWindow()
        buildStatusItem()
        startMouseTracking()
        observe()
        refreshLens(after: 0.3)
        handleDebugFlags()
    }

    private func anotherInstanceIsRunning() -> Bool {
        guard let id = Bundle.main.bundleIdentifier else { return false }
        let me = ProcessInfo.processInfo.processIdentifier
        return NSRunningApplication.runningApplications(withBundleIdentifier: id)
            .contains { $0.processIdentifier != me }
    }

    private var desktopLevel: NSWindow.Level {
        NSWindow.Level(rawValue: Int(CGWindowLevelForKey(.desktopIconWindow)) + 1)
    }

    private func buildWindow() {
        let size = Settings.holeSize
        let center = validCenter(Settings.center) ?? defaultCenter(size: size)
        let frame = NSRect(x: (center.x - size / 2).rounded(), y: (center.y - size / 2).rounded(),
                           width: size, height: size)
        let w = NSWindow(contentRect: frame, styleMask: [.borderless], backing: .buffered, defer: false)
        w.isOpaque = false
        w.backgroundColor = .clear
        w.hasShadow = false
        w.isReleasedWhenClosed = false
        w.collectionBehavior = [.canJoinAllSpaces, .stationary, .ignoresCycle]
        w.title = "Kara Delik"

        let v = HoleView(frame: NSRect(origin: .zero, size: frame.size))
        v.autoresizingMask = [.width, .height]
        v.holeDelegate = self
        let s = HoleScene(size: frame.size)
        v.presentScene(s)
        w.contentView = v

        window = w
        holeView = v
        scene = s
        applyLevel()
        w.orderFrontRegardless()
    }

    private func defaultCenter(size: CGFloat) -> NSPoint {
        let vf = (NSScreen.main ?? NSScreen.screens.first)?.visibleFrame
            ?? NSRect(x: 0, y: 0, width: 1440, height: 900)
        return NSPoint(x: vf.maxX - size * 0.5 - 30, y: vf.minY + size * 0.5 + 30)
    }

    private func validCenter(_ p: NSPoint?) -> NSPoint? {
        guard let p = p else { return nil }
        return NSScreen.screens.contains { $0.frame.contains(p) } ? p : nil
    }

    private func applyLevel() {
        window.level = Settings.alwaysOnTop ? .floating : desktopLevel
        refreshLens(after: 0.05)
    }

    private func applySize(animated: Bool) {
        let size = Settings.holeSize
        let c = NSPoint(x: window.frame.midX, y: window.frame.midY)
        let f = NSRect(x: (c.x - size / 2).rounded(), y: (c.y - size / 2).rounded(), width: size, height: size)
        guard f != window.frame else { return }
        scene.setLensVisible(false)
        window.setFrame(f, display: true, animate: animated)
        refreshLens(after: 0.1)
    }

    // MARK: - Tıklamalar deliğin dışından geçsin

    private func startMouseTracking() {
        let t = Timer(timeInterval: 1.0 / 30.0, target: self, selector: #selector(updateMousePassthrough),
                      userInfo: nil, repeats: true)
        RunLoop.main.add(t, forMode: .common)
        mouseTimer = t
    }

    @objc private func updateMousePassthrough() {
        guard let w = window else { return }
        let m = NSEvent.mouseLocation
        let f = w.frame
        let active = hypot(m.x - f.midX, m.y - f.midY) < f.width * 0.42
        if w.ignoresMouseEvents == active {
            w.ignoresMouseEvents = !active
        }
    }

    // MARK: - Işık bükme (duvar kâğıdı)

    private func observe() {
        let nc = NotificationCenter.default
        nc.addObserver(self, selector: #selector(windowMoved), name: NSWindow.didMoveNotification, object: window)
        nc.addObserver(self, selector: #selector(environmentChanged),
                       name: NSApplication.didChangeScreenParametersNotification, object: nil)
        NSWorkspace.shared.notificationCenter.addObserver(self, selector: #selector(environmentChanged),
                                                          name: NSWorkspace.activeSpaceDidChangeNotification,
                                                          object: nil)
    }

    @objc private func windowMoved() {
        Settings.center = NSPoint(x: window.frame.midX, y: window.frame.midY)
        scene.setLensVisible(false)
        refreshLens(after: 0.3)
    }

    @objc private func environmentChanged() {
        refreshLens(after: 0.5)
    }

    private func refreshLens(after delay: TimeInterval) {
        NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(doRefreshLens), object: nil)
        perform(#selector(doRefreshLens), with: nil, afterDelay: delay, inModes: [.common])
    }

    @objc private func doRefreshLens() {
        guard Settings.lensingOn, !Settings.alwaysOnTop, let req = Wallpaper.request(for: window) else {
            scene.setBackground(nil)
            return
        }
        lensGeneration += 1
        let gen = lensGeneration
        lensQueue.async { [weak self] in
            let img = Wallpaper.render(req)
            DispatchQueue.main.async {
                guard let self = self, gen == self.lensGeneration else { return }
                self.scene.setBackground(img)
                self.scene.setLensVisible(img != nil)
            }
        }
    }

    // MARK: - HoleViewDelegate

    func holeView(_ view: HoleView, didReceive urls: [URL], at point: NSPoint) {
        let start = view.convert(point, to: scene)
        var toTrash: [URL] = []
        var volumes: [URL] = []
        var refused: [URL] = []
        for u in urls {
            if Self.isProtected(u) {
                refused.append(u)
            } else if (try? u.resourceValues(forKeys: [.isVolumeKey]))?.isVolume == true {
                volumes.append(u)
            } else {
                toTrash.append(u)
            }
        }

        // 1) Animasyon hemen başlasın
        let shown = Array((toTrash + volumes).prefix(24))
        var nodes: [SKSpriteNode] = []
        for (i, u) in shown.enumerated() {
            let icon = NSWorkspace.shared.icon(forFile: u.path)
            icon.size = NSSize(width: 128, height: 128)
            let p = i == 0 ? start : CGPoint(x: start.x + CGFloat.random(in: -16...16),
                                             y: start.y + CGFloat.random(in: -16...16))
            nodes.append(scene.swallow(texture: SKTexture(image: icon), aspect: 1, from: p, delay: Double(i) * 0.09))
        }
        if !shown.isEmpty { Sound.play("swallow") }

        // 2) Gerçek küçük resimleri (fotoğraf vs.) yükle, gelince ikonu değiştir
        let group = DispatchGroup()
        let scale = window.backingScaleFactor
        for (i, u) in shown.enumerated() where i < nodes.count {
            group.enter()
            let req = QLThumbnailGenerator.Request(fileAt: u, size: CGSize(width: 128, height: 128),
                                                   scale: scale, representationTypes: .thumbnail)
            let node = nodes[i]
            QLThumbnailGenerator.shared.generateBestRepresentation(for: req) { rep, _ in
                let cg = rep?.cgImage
                DispatchQueue.main.async {
                    if let cg = cg {
                        self.scene.replaceTexture(of: node, with: SKTexture(cgImage: cg),
                                                  aspect: CGFloat(cg.width) / CGFloat(max(1, cg.height)))
                    }
                    group.leave()
                }
            }
        }

        // 3) Yutulan boyutu say (kara delik büyüsün)
        let counted = toTrash
        group.enter()
        DispatchQueue.global(qos: .userInitiated).async {
            let bytes = counted.reduce(Int64(0)) { $0 + FileSize.allocated($1, budget: 0.4) }
            DispatchQueue.main.async {
                Settings.eatenBytes += Double(bytes)
                Settings.eatenCount += counted.count
                group.leave()
            }
        }

        // 4) Çöp Sepeti'ne taşı (küçük resimler gelince ya da en geç 0.7 sn sonra)
        let once = Once()
        let trashNow: () -> Void = { [weak self] in
            guard !once.done else { return }
            once.done = true
            self?.recycle(toTrash)
            self?.eject(volumes)
        }
        group.notify(queue: .main, execute: trashNow)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7, execute: trashNow)

        // 5) Animasyon bitince büyü
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.1 + Double(shown.count) * 0.09) { [weak self] in
            self?.applySize(animated: true)
        }

        if !refused.isEmpty {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self] in
                guard let self = self else { return }
                for u in refused.prefix(4) {
                    let icon = NSWorkspace.shared.icon(forFile: u.path)
                    icon.size = NSSize(width: 128, height: 128)
                    self.scene.spit(texture: SKTexture(image: icon))
                }
                Sound.play("poke")
                self.showAlert(title: "Bunu yutmam tehlikeli",
                               text: "Sistem ve ana klasörleri (Masaüstü, Belgeler, İndirilenler, Uygulamalar…) kara delik yutmaz.")
            }
        }
    }

    func holeViewDoubleClicked(_ view: HoleView) { openTrash() }

    func holeViewWillMove(_ view: HoleView) { scene.setLensVisible(false) }

    func holeViewMenu(_ view: HoleView) -> NSMenu {
        let m = NSMenu()
        populate(m)
        return m
    }

    // MARK: - Dosya işlemleri

    static func isProtected(_ url: URL) -> Bool {
        let p = url.standardizedFileURL.path
        let home = NSHomeDirectory()
        let locked: Set<String> = [
            "/", "/Applications", "/System", "/Library", "/Users", "/Volumes", "/private", "/usr", "/bin", "/sbin",
            home, home + "/Desktop", home + "/Documents", home + "/Downloads", home + "/Library",
            home + "/Pictures", home + "/Movies", home + "/Music", home + "/Applications", home + "/.Trash"
        ]
        if locked.contains(p) { return true }
        if p == Bundle.main.bundleURL.standardizedFileURL.path { return true }
        return false
    }

    private func recycle(_ urls: [URL]) {
        guard !urls.isEmpty else { return }
        NSWorkspace.shared.recycle(urls) { [weak self] trashed, error in
            let okPaths = Set(trashed.keys.map { $0.standardizedFileURL.path })
            DispatchQueue.main.async {
                guard let self = self, error != nil else { return }
                let failed = urls.filter { !okPaths.contains($0.standardizedFileURL.path) }
                self.spitOut(failed.isEmpty ? urls : failed, error: error)
            }
        }
    }

    private func eject(_ volumes: [URL]) {
        for v in volumes {
            DispatchQueue.global(qos: .userInitiated).async {
                do {
                    try NSWorkspace.shared.unmountAndEjectDevice(at: v)
                } catch {
                    DispatchQueue.main.async { [weak self] in
                        self?.spitOut([v], error: error)
                    }
                }
            }
        }
    }

    private func spitOut(_ failed: [URL], error: Error?) {
        for u in failed.prefix(4) {
            let icon = NSWorkspace.shared.icon(forFile: u.path)
            icon.size = NSSize(width: 128, height: 128)
            scene.spit(texture: SKTexture(image: icon))
        }
        Sound.play("poke")
        let names = failed.prefix(3).map { $0.lastPathComponent }.joined(separator: ", ")
        showAlert(title: "Kara delik bunu yutamadı", text: "\(names)\n\n\(error?.localizedDescription ?? "")")
    }

    // MARK: - Menü

    private func buildStatusItem() {
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        statusItem.button?.image = Self.menuBarIcon()
        statusItem.button?.toolTip = "Kara Delik"
        let menu = NSMenu()
        menu.delegate = self
        statusItem.menu = menu
    }

    func menuNeedsUpdate(_ menu: NSMenu) { populate(menu) }

    private func populate(_ menu: NSMenu) {
        menu.removeAllItems()
        menu.autoenablesItems = false

        let stats = NSMenuItem(title: statsText(), action: nil, keyEquivalent: "")
        stats.isEnabled = false
        menu.addItem(stats)
        menu.addItem(.separator())

        menu.addItem(item("Her Zaman Üstte", #selector(toggleOnTop), on: Settings.alwaysOnTop))
        let lens = item("Işığı Bük (deneysel)", #selector(toggleLens), on: Settings.lensingOn)
        lens.isEnabled = !Settings.alwaysOnTop
        menu.addItem(lens)
        menu.addItem(item("Ses", #selector(toggleSound), on: Settings.soundOn))

        let sizeItem = NSMenuItem(title: "Boyut", action: nil, keyEquivalent: "")
        let sub = NSMenu()
        sub.autoenablesItems = false
        for (i, name) in ["Küçük", "Orta", "Büyük"].enumerated() {
            let it = item(name, #selector(setSize(_:)), on: Settings.sizeLevel == i)
            it.tag = i
            sub.addItem(it)
        }
        sizeItem.submenu = sub
        menu.addItem(sizeItem)
        menu.addItem(.separator())

        menu.addItem(item("Çöp Sepeti'ni Aç", #selector(openTrash)))
        menu.addItem(item("Çöp Sepeti'ni Boşalt…", #selector(emptyTrash)))
        menu.addItem(item("Kara Deliği Küçült", #selector(resetGrowth)))
        menu.addItem(.separator())
        menu.addItem(item("berkay.instaassist.tr/kara-delik", #selector(openSite)))

        let quit = NSMenuItem(title: "Kara Delik'ten Çık", action: #selector(NSApplication.terminate(_:)),
                              keyEquivalent: "q")
        quit.target = NSApp
        menu.addItem(quit)
    }

    private func item(_ title: String, _ action: Selector, on: Bool? = nil) -> NSMenuItem {
        let it = NSMenuItem(title: title, action: action, keyEquivalent: "")
        it.target = self
        if let on = on { it.state = on ? .on : .off }
        return it
    }

    private func statsText() -> String {
        let n = Settings.eatenCount
        guard n > 0 else { return "Henüz hiçbir şey yutmadı" }
        let size = ByteCountFormatter.string(fromByteCount: Int64(Settings.eatenBytes), countStyle: .file)
        return "\(n) şey yuttu · \(size)"
    }

    @objc private func toggleOnTop() {
        Settings.alwaysOnTop.toggle()
        applyLevel()
    }

    @objc private func toggleLens() {
        Settings.lensingOn.toggle()
        refreshLens(after: 0)
    }

    @objc private func toggleSound() { Settings.soundOn.toggle() }

    @objc private func setSize(_ sender: NSMenuItem) {
        Settings.sizeLevel = sender.tag
        applySize(animated: true)
    }

    @objc private func resetGrowth() {
        Settings.eatenBytes = 0
        Settings.eatenCount = 0
        applySize(animated: true)
    }

    @objc private func openTrash() {
        let trash = URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent(".Trash")
        if !NSWorkspace.shared.open(trash) {
            runOsascript("tell application \"Finder\" to open trash\ntell application \"Finder\" to activate") { _, _ in }
        }
    }

    @objc private func openSite() {
        if let url = URL(string: "https://berkay.instaassist.tr/kara-delik") { NSWorkspace.shared.open(url) }
    }

    @objc private func emptyTrash() {
        activateApp()
        let a = NSAlert()
        a.messageText = "Çöp Sepeti boşaltılsın mı?"
        a.informativeText = "Çöp Sepeti'ndeki her şey kalıcı olarak silinecek. Bu işlem geri alınamaz."
        a.alertStyle = .warning
        a.addButton(withTitle: "Boşalt")
        a.addButton(withTitle: "Vazgeç")
        guard a.runModal() == .alertFirstButtonReturn else { return }

        runOsascript("tell application \"Finder\" to empty trash") { [weak self] ok, message in
            guard let self = self else { return }
            if ok {
                self.evaporate()
            } else {
                self.showAlert(title: "Çöp Sepeti boşaltılamadı",
                               text: "Kara Delik'in Finder'ı yönetmesine izin ver: Sistem Ayarları › Gizlilik ve Güvenlik › Otomasyon › Kara Delik › Finder.\n\n\(message)")
            }
        }
    }

    private func evaporate() {
        Sound.play("evaporate")
        scene.evaporate { [weak self] in
            Settings.eatenBytes = 0
            Settings.eatenCount = 0
            self?.applySize(animated: true)
        }
    }

    /// AppleScript'i ayrı süreçte çalıştırır (arayüz donmasın).
    private func runOsascript(_ script: String, completion: @escaping (Bool, String) -> Void) {
        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
        p.arguments = ["-e", script]
        let errPipe = Pipe()
        p.standardError = errPipe
        p.standardOutput = Pipe()
        p.terminationHandler = { proc in
            let data = errPipe.fileHandleForReading.readDataToEndOfFile()
            let msg = String(data: data, encoding: .utf8) ?? ""
            let ok = proc.terminationStatus == 0
            DispatchQueue.main.async { completion(ok, msg) }
        }
        do {
            try p.run()
        } catch {
            completion(false, error.localizedDescription)
        }
    }

    private func activateApp() {
        if #available(macOS 14.0, *) {
            NSApp.activate()
        } else {
            NSApp.activate(ignoringOtherApps: true)
        }
    }

    private func showAlert(title: String, text: String) {
        activateApp()
        let a = NSAlert()
        a.messageText = title
        a.informativeText = text
        a.addButton(withTitle: "Tamam")
        a.runModal()
    }

    static func menuBarIcon() -> NSImage {
        let img = NSImage(size: NSSize(width: 18, height: 18), flipped: false) { _ in
            NSColor.black.set()
            let disk = NSBezierPath(ovalIn: NSRect(x: 1.2, y: 6.2, width: 15.6, height: 5.6))
            disk.lineWidth = 1.4
            disk.stroke()
            NSBezierPath(ovalIn: NSRect(x: 5.25, y: 5.25, width: 7.5, height: 7.5)).fill()
            return true
        }
        img.isTemplate = true
        return img
    }

    // MARK: - Test modu: --snapshot <klasör> [--quit]

    private func handleDebugFlags() {
        let args = CommandLine.arguments
        guard let i = args.firstIndex(of: "--snapshot"), i + 1 < args.count else { return }
        let dir = args[i + 1]
        let quit = args.contains("--quit")
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            self.snapshot(to: dir + "/snap_idle.png")
            self.scene.demoSwallow()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
                self.snapshot(to: dir + "/snap_swallow_1.png")
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.snapshot(to: dir + "/snap_swallow_2.png")
                    if quit {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { NSApp.terminate(nil) }
                    }
                }
            }
        }
    }

    private func snapshot(to path: String) {
        guard let tex = holeView.texture(from: scene) else {
            print("snapshot: texture yok")
            return
        }
        let cg = tex.cgImage()
        let url = URL(fileURLWithPath: path)
        guard let dest = CGImageDestinationCreateWithURL(url as CFURL, UTType.png.identifier as CFString, 1, nil) else {
            print("snapshot: dosya açılamadı \(path)")
            return
        }
        CGImageDestinationAddImage(dest, cg, nil)
        CGImageDestinationFinalize(dest)
        print("snapshot -> \(path)")
    }
}
