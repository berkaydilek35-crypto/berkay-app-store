import AppKit
import SpriteKit
import UniformTypeIdentifiers

func smoothstep(_ e0: CGFloat, _ e1: CGFloat, _ x: CGFloat) -> CGFloat {
    let t = max(0, min(1, (x - e0) / (e1 - e0)))
    return t * t * (3 - 2 * t)
}

final class HoleScene: SKScene {
    /// Olay ufku yarıçapı / sahne genişliği (shader ile aynı olmalı).
    static let horizonFraction: CGFloat = 0.11

    static let blankTexture = SKTexture(data: Data([0, 0, 0, 255]), size: CGSize(width: 1, height: 1))

    static let dotTexture: SKTexture = {
        let img = NSImage(size: NSSize(width: 32, height: 32), flipped: false) { rect in
            if let g = NSGradient(colors: [NSColor.white, NSColor.white.withAlphaComponent(0)]) {
                g.draw(in: NSBezierPath(ovalIn: rect), relativeCenterPosition: .zero)
            }
            return true
        }
        return SKTexture(image: img)
    }()

    private let hole = SKSpriteNode(color: .white, size: CGSize(width: 10, height: 10))
    private let uPhase = SKUniform(name: "u_phase", float: 0)
    private let uRadius = SKUniform(name: "u_radius", float: Float(HoleScene.horizonFraction))
    private let uPulse = SKUniform(name: "u_pulse", float: 0)
    private let uGlow = SKUniform(name: "u_glow", float: 1)
    private let uLens = SKUniform(name: "u_lens", float: 0)
    private let uEvap = SKUniform(name: "u_evap", float: 0)
    private let uBg = SKUniform(name: "u_bg", texture: HoleScene.blankTexture)

    private var lastTime: TimeInterval = 0
    private var phase: CGFloat = 0
    private var spin: CGFloat = 0.35
    private var targetSpin: CGFloat = 0.35
    private var glow: CGFloat = 1
    private var targetGlow: CGFloat = 1
    private var pulse: CGFloat = 0
    private var lens: CGFloat = 0
    private var lensTarget: CGFloat = 0
    private var hasBackground = false
    private var evap: CGFloat = 0

    var horizon: CGFloat { size.width * HoleScene.horizonFraction }

    override init(size: CGSize) {
        super.init(size: size)
        backgroundColor = .clear
        anchorPoint = CGPoint(x: 0.5, y: 0.5)
        scaleMode = .resizeFill
        hole.shader = SKShader(source: HoleScene.shaderSource,
                               uniforms: [uPhase, uRadius, uPulse, uGlow, uLens, uEvap, uBg])
        hole.size = size
        hole.position = .zero
        hole.zPosition = 0
        addChild(hole)
    }

    required init?(coder aDecoder: NSCoder) { fatalError("init(coder:) kullanılmıyor") }

    override func didChangeSize(_ oldSize: CGSize) {
        super.didChangeSize(oldSize)
        hole.size = size
    }

    override func update(_ currentTime: TimeInterval) {
        let dt: CGFloat = lastTime == 0 ? 1.0 / 60.0 : CGFloat(min(0.05, max(0, currentTime - lastTime)))
        lastTime = currentTime
        spin += (targetSpin + pulse * 1.5 - spin) * min(1, dt * 3)
        glow += (targetGlow - glow) * min(1, dt * 4)
        lens += (lensTarget - lens) * min(1, dt * 5)
        pulse = max(0, pulse - dt * 1.6)
        phase += dt * spin
        // 10π: tüm katmanların (1.0, 0.6, 0.2 hız) ortak periyodu → dikiş yok
        phase = phase.truncatingRemainder(dividingBy: 10 * .pi)
        uPhase.floatValue = Float(phase)
        uGlow.floatValue = Float(glow + pulse * 0.8)
        uPulse.floatValue = Float(pulse)
        uLens.floatValue = Float(lens)
        uEvap.floatValue = Float(evap)
    }

    // MARK: - Durum

    /// 0 = boşta, 1 = dosya çok yakın.
    func setAttraction(_ amount: CGFloat) {
        let a = max(0, min(1, amount))
        targetSpin = 0.35 + 1.5 * a
        targetGlow = 1 + 0.9 * a
    }

    func setBackground(_ image: CGImage?) {
        if let img = image {
            uBg.textureValue = SKTexture(cgImage: img)
            hasBackground = true
        } else {
            uBg.textureValue = HoleScene.blankTexture
            hasBackground = false
            lensTarget = 0
        }
    }

    func setLensVisible(_ on: Bool) {
        lensTarget = (on && hasBackground) ? 1 : 0
        if !on { lens = min(lens, 0.0) } // taşınırken anında gizle
    }

    func poke() { pulse = min(1, pulse + 0.5) }

    private func gulp() { pulse = min(1, pulse + 0.7) }

    // MARK: - Yutma

    private func fitted(aspect: CGFloat) -> CGSize {
        let box = size.width * 0.22
        let a = max(0.2, min(5, aspect))
        return a >= 1 ? CGSize(width: box, height: box / a) : CGSize(width: box * a, height: box)
    }

    func replaceTexture(of node: SKSpriteNode, with tex: SKTexture, aspect: CGFloat) {
        guard node.parent != nil else { return }
        node.texture = tex
        node.size = fitted(aspect: aspect)
    }

    private func makeTrail() -> SKEmitterNode {
        let e = SKEmitterNode()
        e.particleTexture = HoleScene.dotTexture
        e.particleBirthRate = 0
        e.particleLifetime = 0.45
        e.particleLifetimeRange = 0.2
        e.particleSpeed = 10
        e.particleSpeedRange = 10
        e.emissionAngleRange = .pi * 2
        e.particleAlpha = 0.9
        e.particleAlphaSpeed = -2.0
        e.particleScale = 0.14
        e.particleScaleRange = 0.07
        e.particleScaleSpeed = -0.25
        e.particleColor = NSColor(calibratedRed: 1, green: 0.6, blue: 0.25, alpha: 1)
        e.particleColorBlendFactor = 1
        e.particleBlendMode = .add
        return e
    }

    /// Dosya ikonunu sarmal çizerek, uzayıp incelerek (spagettileşme) olay ufkuna çeker.
    @discardableResult
    func swallow(texture: SKTexture, aspect: CGFloat, from start: CGPoint, delay: TimeInterval) -> SKSpriteNode {
        let node = SKSpriteNode(texture: texture)
        node.size = fitted(aspect: aspect)
        node.position = start
        node.zPosition = 10
        node.alpha = 0
        node.color = NSColor(calibratedRed: 1, green: 0.32, blue: 0.08, alpha: 1)
        node.colorBlendFactor = 0
        addChild(node)

        let trail = makeTrail()
        trail.position = start
        trail.targetNode = self
        trail.zPosition = 9
        addChild(trail)

        let half = size.width * 0.5
        let end = horizon * 0.85
        let r0 = max(hypot(start.x, start.y), horizon * 1.8)
        let theta0 = atan2(start.y, start.x)
        let a0 = theta0.remainder(dividingBy: .pi)
        let reach = min(1, r0 / half)
        let duration = 1.45 + 0.4 * Double(reach)
        let turns = 0.9 + 0.7 * reach
        let dir: CGFloat = -1 // saat yönü — disk de bu yönde dönüyor

        let spiral = SKAction.customAction(withDuration: duration) { n, elapsed in
            guard let s = n as? SKSpriteNode else { return }
            let u = min(1, elapsed / CGFloat(duration))
            let fall = pow(u, 2.1)
            let r = end + (r0 - end) * (1 - fall)
            let theta = theta0 + dir * turns * 2 * .pi * pow(u, 2.3)
            let pos = CGPoint(x: cos(theta) * r, y: sin(theta) * r)
            s.position = pos
            trail.position = pos
            trail.particleBirthRate = 40 + 220 * u
            // Radyal yöne hizalan, sonra boyuna uza / enine incel
            let align = smoothstep(0, 0.35, u)
            s.zRotation = (a0 + (theta - theta0)) * align
            let shrink = 0.2 + 0.8 * max(0, (r - end) / max(1, r0 - end))
            let stretch = 1 + 3.4 * pow(u, 3)
            let squeeze = max(0.035, 1 - 0.93 * pow(u, 1.5))
            s.xScale = shrink * stretch
            s.yScale = shrink * squeeze
            s.colorBlendFactor = 0.75 * u * u   // kırmızıya kayma
            s.alpha = u < 0.8 ? 1 : max(0, 1 - (u - 0.8) / 0.2)
        }

        let begin = SKAction.run { node.alpha = 1 }
        let finish = SKAction.run { [weak self] in
            trail.particleBirthRate = 0
            trail.run(.sequence([.wait(forDuration: 0.6), .removeFromParent()]))
            self?.gulp()
        }
        node.run(.sequence([.wait(forDuration: delay), begin, spiral, finish, .removeFromParent()]))
        return node
    }

    /// Yutulamayan dosyayı geri tükürür.
    func spit(texture: SKTexture) {
        let node = SKSpriteNode(texture: texture)
        node.size = fitted(aspect: 1)
        node.position = .zero
        node.zPosition = 15
        node.setScale(0.2)
        addChild(node)
        let angle = CGFloat.random(in: 0..<(2 * .pi))
        let dist = size.width * 0.3
        let move = SKAction.move(to: CGPoint(x: cos(angle) * dist, y: sin(angle) * dist), duration: 0.55)
        move.timingMode = .easeOut
        let grow = SKAction.scale(to: 1, duration: 0.55)
        let turn = SKAction.rotate(byAngle: .pi * 3, duration: 0.55)
        node.run(.sequence([.group([move, grow, turn]),
                            .wait(forDuration: 0.6),
                            .fadeOut(withDuration: 0.4),
                            .removeFromParent()]))
        pulse = 1
    }

    // MARK: - Hawking buharlaşması (çöp boşaltılınca)

    func evaporate(completion: @escaping () -> Void) {
        let up = SKAction.customAction(withDuration: 1.1) { [weak self] _, t in
            self?.evap = pow(t / 1.1, 1.5)
        }
        let burst = SKAction.run { [weak self] in self?.hawkingBurst() }
        let down = SKAction.customAction(withDuration: 1.0) { [weak self] _, t in
            self?.evap = 1 - smoothstep(0, 1, t / 1.0)
        }
        run(.sequence([up, burst, .wait(forDuration: 0.25), down, .run { [weak self] in
            self?.evap = 0
            completion()
        }]))
    }

    private func hawkingBurst() {
        let e = SKEmitterNode()
        e.particleTexture = HoleScene.dotTexture
        e.numParticlesToEmit = 260
        e.particleBirthRate = 2600
        e.particleLifetime = 1.1
        e.particleLifetimeRange = 0.4
        e.particleSpeed = size.width * 0.22
        e.particleSpeedRange = size.width * 0.12
        e.emissionAngleRange = .pi * 2
        e.particleAlpha = 1
        e.particleAlphaSpeed = -0.9
        e.particleScale = 0.18
        e.particleScaleRange = 0.1
        e.particleScaleSpeed = -0.1
        e.particleColor = NSColor(calibratedRed: 0.75, green: 0.9, blue: 1, alpha: 1)
        e.particleColorBlendFactor = 1
        e.particleBlendMode = .add
        e.position = .zero
        e.zPosition = 20
        addChild(e)
        e.run(.sequence([.wait(forDuration: 2.0), .removeFromParent()]))
        pulse = 1
    }

    // MARK: - Test

    func demoSwallow() {
        let icon = NSWorkspace.shared.icon(for: .pdf)
        icon.size = NSSize(width: 128, height: 128)
        swallow(texture: SKTexture(image: icon), aspect: 1,
                from: CGPoint(x: -size.width * 0.3, y: size.width * 0.2), delay: 0)
    }
}
