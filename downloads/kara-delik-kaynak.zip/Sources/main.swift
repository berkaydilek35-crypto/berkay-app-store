import AppKit

// Kara Delik — masaüstündeki çöp sepeti.
// Menü çubuğu uygulaması olarak çalışır (Dock'ta görünmez).

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.setActivationPolicy(.accessory)
app.run()
