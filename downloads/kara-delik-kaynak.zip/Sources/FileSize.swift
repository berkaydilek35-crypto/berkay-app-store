import Foundation

enum FileSize {
    /// Diskte kapladığı yer. Klasörlerde en fazla `budget` saniye sayar.
    static func allocated(_ url: URL, budget: TimeInterval) -> Int64 {
        let keys: Set<URLResourceKey> = [.isDirectoryKey, .totalFileAllocatedSizeKey, .fileAllocatedSizeKey]
        guard let v = try? url.resourceValues(forKeys: keys) else { return 0 }
        if v.isDirectory != true {
            return Int64(v.totalFileAllocatedSize ?? v.fileAllocatedSize ?? 0)
        }
        let fileKeys: [URLResourceKey] = [.totalFileAllocatedSizeKey, .fileAllocatedSizeKey]
        guard let e = FileManager.default.enumerator(at: url,
                                                     includingPropertiesForKeys: fileKeys,
                                                     options: [],
                                                     errorHandler: { _, _ in true }) else { return 0 }
        let deadline = Date().addingTimeInterval(budget)
        var total: Int64 = 0
        var n = 0
        for case let f as URL in e {
            if let fv = try? f.resourceValues(forKeys: Set(fileKeys)) {
                total += Int64(fv.totalFileAllocatedSize ?? fv.fileAllocatedSize ?? 0)
            }
            n += 1
            if n % 200 == 0 && Date() > deadline { break }
        }
        return total
    }
}
