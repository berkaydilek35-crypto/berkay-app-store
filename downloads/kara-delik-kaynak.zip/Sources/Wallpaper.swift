import AppKit
import ImageIO

/// Kara deliğin arkasında kalan duvar kâğıdı parçasını çıkarır (ışık bükme efekti için).
enum Wallpaper {
    struct Request {
        let url: URL
        let scaling: NSImageScaling
        let allowClipping: Bool
        let fill: CGColor
        let screenFrame: NSRect
        let backingScale: CGFloat
        let rect: NSRect
    }

    // Sadece arka plan kuyruğundan erişilir.
    private static var cachedURL: URL?
    private static var cachedImage: CGImage?
    private static var cachedOriginalSize: CGSize = .zero

    /// Ana iş parçacığında çağrılır.
    static func request(for window: NSWindow) -> Request? {
        guard let screen = window.screen ?? NSScreen.main,
              let url = NSWorkspace.shared.desktopImageURL(for: screen) else { return nil }
        let opts = NSWorkspace.shared.desktopImageOptions(for: screen) ?? [:]
        let raw = (opts[.imageScaling] as? NSNumber)?.uintValue ?? NSImageScaling.scaleProportionallyUpOrDown.rawValue
        let scaling = NSImageScaling(rawValue: raw) ?? .scaleProportionallyUpOrDown
        let allowClip = (opts[.allowClipping] as? NSNumber)?.boolValue ?? true
        let fillColor = ((opts[.fillColor] as? NSColor)?.usingColorSpace(.sRGB) ?? NSColor.black).cgColor
        return Request(url: url,
                       scaling: scaling,
                       allowClipping: allowClip,
                       fill: fillColor,
                       screenFrame: screen.frame,
                       backingScale: screen.backingScaleFactor,
                       rect: window.frame)
    }

    private static func load(_ url: URL) -> CGImage? {
        if url == cachedURL, let img = cachedImage { return img }
        var isDir: ObjCBool = false
        guard FileManager.default.fileExists(atPath: url.path, isDirectory: &isDir), !isDir.boolValue,
              let src = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
        var original = CGSize.zero
        if let props = CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [CFString: Any],
           let w = props[kCGImagePropertyPixelWidth] as? Int,
           let h = props[kCGImagePropertyPixelHeight] as? Int {
            original = CGSize(width: w, height: h)
        }
        // Çok büyük duvar kâğıtlarını küçült (hız için).
        let opts: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceThumbnailMaxPixelSize: 4096,
            kCGImageSourceCreateThumbnailWithTransform: true
        ]
        guard let img = CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary) else { return nil }
        if original == .zero { original = CGSize(width: img.width, height: img.height) }
        cachedURL = url
        cachedImage = img
        cachedOriginalSize = original
        return img
    }

    /// Arka plan kuyruğunda çağrılır.
    static func render(_ r: Request) -> CGImage? {
        guard let img = load(r.url) else { return nil }
        let sf = r.screenFrame
        let iw = CGFloat(img.width), ih = CGFloat(img.height)
        guard iw > 0, ih > 0 else { return nil }

        // Duvar kâğıdının ekranda nereye çizildiği (ekrana göre, nokta cinsinden).
        var draw: NSRect
        switch r.scaling {
        case .scaleAxesIndependently:
            draw = NSRect(x: 0, y: 0, width: sf.width, height: sf.height)
        case .scaleNone:
            let w = cachedOriginalSize.width / r.backingScale
            let h = cachedOriginalSize.height / r.backingScale
            draw = NSRect(x: (sf.width - w) / 2, y: (sf.height - h) / 2, width: w, height: h)
        default:
            let sx = sf.width / iw, sy = sf.height / ih
            let s = r.allowClipping ? max(sx, sy) : min(sx, sy)
            let w = iw * s, h = ih * s
            draw = NSRect(x: (sf.width - w) / 2, y: (sf.height - h) / 2, width: w, height: h)
        }

        let scale = r.backingScale
        let pw = max(1, Int(r.rect.width * scale))
        let ph = max(1, Int(r.rect.height * scale))
        guard let cs = CGColorSpace(name: CGColorSpace.sRGB),
              let ctx = CGContext(data: nil, width: pw, height: ph, bitsPerComponent: 8, bytesPerRow: 0,
                                  space: cs, bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
        ctx.setFillColor(r.fill)
        ctx.fill(CGRect(x: 0, y: 0, width: pw, height: ph))
        ctx.interpolationQuality = .high
        let ox = (draw.minX - (r.rect.minX - sf.minX)) * scale
        let oy = (draw.minY - (r.rect.minY - sf.minY)) * scale
        ctx.draw(img, in: CGRect(x: ox, y: oy, width: draw.width * scale, height: draw.height * scale))
        return ctx.makeImage()
    }
}
