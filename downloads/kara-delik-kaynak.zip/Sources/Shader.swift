import SpriteKit

extension HoleScene {
    /// Kara delik: olay ufku + foton halkası + dönen toplanma diski + duvar kâğıdını büken mercek.
    /// Çıktı premultiplied alpha. Koordinatlar: v_tex_coord 0..1, merkez 0.5.
    static let shaderSource = """
    float hash21(vec2 p) {
        p = fract(p * vec2(123.34, 456.21));
        p += dot(p, p + 45.32);
        return fract(p.x * p.y);
    }

    float vnoise(vec2 p) {
        vec2 i = floor(p);
        vec2 f = fract(p);
        vec2 u = f * f * (3.0 - 2.0 * f);
        float a = hash21(i);
        float b = hash21(i + vec2(1.0, 0.0));
        float c = hash21(i + vec2(0.0, 1.0));
        float d = hash21(i + vec2(1.0, 1.0));
        return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
    }

    float fbm(vec2 p) {
        float v = 0.0;
        float a = 0.5;
        for (int i = 0; i < 4; i++) {
            v += a * vnoise(p);
            p = p * 2.07 + vec2(1.7, 9.2);
            a *= 0.5;
        }
        return v;
    }

    vec2 rot2(vec2 p, float a) {
        float c = cos(a);
        float s = sin(a);
        return vec2(c * p.x - s * p.y, s * p.x + c * p.y);
    }

    void main() {
        vec2 p = v_tex_coord - vec2(0.5);
        vec2 pc = p + vec2(0.00001, 0.00002);
        float r = max(length(p), 0.0001);
        float R = u_radius * (1.0 + 0.07 * u_pulse) * (1.0 - 0.85 * u_evap);
        R = max(R, 0.004);
        vec2 dir = p / r;

        // --- Kütleçekimsel mercek: arkadaki duvar kâğıdını bük ---
        vec4 base = vec4(0.0);
        if (u_lens > 0.001) {
            float thetaE = R * 1.8;
            float fall = 1.0 - smoothstep(R * 2.2, R * 3.6, r);
            float defl = (thetaE * thetaE / r) * fall;
            vec2 src = vec2(0.5) + dir * (r - defl);
            src = clamp(src, vec2(0.001), vec2(0.999));
            vec3 bg = texture2D(u_bg, src).rgb;
            float la = (1.0 - smoothstep(R * 3.2, R * 3.95, r)) * u_lens;
            base = vec4(bg * la, la);
        }

        // --- Toplanma diski (içe doğru akan sarmal) ---
        float rin = R * 1.25;
        float rout = R * 3.5;
        float dn = clamp((r - rin) / (rout - rin), 0.0, 1.0);
        float twist = 2.6 * log(max(r / R, 0.05));
        vec2 q1 = rot2(pc, u_phase + twist);
        vec2 q2 = rot2(pc, u_phase * 0.6 + twist * 1.3 + 1.3);
        float n1 = fbm(q1 / R * 1.6);
        float n2 = fbm(q2 / R * 3.2 + vec2(5.0, 1.0));
        float arms = 0.5 + 0.5 * sin(3.0 * atan(q1.y, q1.x) + n1 * 5.0);
        float density = (0.25 + 0.75 * arms) * (0.45 + 0.9 * n2);
        float diskMask = smoothstep(rin * 0.92, rin * 1.18, r) * (1.0 - smoothstep(rout * 0.55, rout, r));
        float heat = pow(1.0 - dn, 1.7);
        vec3 cool = vec3(0.45, 0.07, 0.02);
        vec3 warm = vec3(1.0, 0.45, 0.10);
        vec3 hot = vec3(1.0, 0.93, 0.80);
        vec3 diskCol = mix(cool, warm, smoothstep(0.0, 0.55, heat));
        diskCol = mix(diskCol, hot, smoothstep(0.55, 1.0, heat));
        float doppler = 0.8 + 0.3 * sin(atan(pc.y, pc.x) + u_phase * 0.2);
        vec3 emit = diskCol * density * diskMask * (0.35 + 1.25 * heat) * doppler * u_glow;

        // --- Foton halkası ---
        float rr = (r - R * 1.1) / (R * 0.05);
        float ring = exp(-rr * rr);
        emit += vec3(1.0, 0.86, 0.62) * ring * (1.1 + 2.2 * u_pulse);

        // --- Hale ---
        float outside = max(r - R, 0.0);
        emit += vec3(1.0, 0.45, 0.15) * exp(-outside / (R * 1.4)) * 0.22 * u_glow;

        // --- Hawking buharlaşması parlaması ---
        emit += vec3(0.7, 0.85, 1.0) * u_evap * exp(-outside / (R * 0.8)) * 1.5;

        float ea = clamp(max(max(emit.r, emit.g), emit.b), 0.0, 1.0);
        vec4 outc = vec4(emit + base.rgb * (1.0 - ea), ea + base.a * (1.0 - ea));

        // --- Olay ufku ---
        float holeMask = 1.0 - smoothstep(R * 0.96, R * 1.02, r);
        outc = mix(outc, vec4(0.0, 0.0, 0.0, 1.0), holeMask);

        // Kare kenar görünmesin
        float edge = 1.0 - smoothstep(0.44, 0.495, r);
        gl_FragColor = outc * edge;
    }
    """
}
